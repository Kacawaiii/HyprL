#!/usr/bin/env python3
"""Alpaca execution bridge for core_v3 signals (JSONL).

This bridge tails a signal JSONL file and places Alpaca paper/live orders
without modifying core_v3. It uses a state file for dedupe and safe restarts.
"""

from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import os
import time
import math
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from dataclasses import asdict, dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, Optional, Set, List
import urllib.request


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def is_rth_now() -> bool:
    """Check if current time is during Regular Trading Hours (9:30-16:00 ET)."""
    try:
        from zoneinfo import ZoneInfo
    except ImportError:
        return True  # Fallback: assume RTH
    et = ZoneInfo("America/New_York")
    now_et = datetime.now(et)
    # Weekday check (Mon=0, Fri=4)
    if now_et.weekday() > 4:
        return False
    market_open = now_et.replace(hour=9, minute=30, second=0, microsecond=0)
    market_close = now_et.replace(hour=16, minute=0, second=0, microsecond=0)
    return market_open <= now_et <= market_close


def minutes_to_market_close() -> Optional[int]:
    """Return minutes until market close (16:00 ET), or None if market not open."""
    try:
        from zoneinfo import ZoneInfo
    except ImportError:
        return None
    et = ZoneInfo("America/New_York")
    now_et = datetime.now(et)
    if now_et.weekday() > 4:
        return None  # Weekend
    market_close = now_et.replace(hour=16, minute=0, second=0, microsecond=0)
    market_open = now_et.replace(hour=9, minute=30, second=0, microsecond=0)
    if now_et < market_open or now_et >= market_close:
        return None  # Market not open
    delta = market_close - now_et
    return int(delta.total_seconds() / 60)


def parse_ts(ts: str) -> datetime:
    return datetime.fromisoformat(ts.replace("Z", "+00:00"))


def stable_client_order_id(symbol: str, ts: str, decision: str) -> str:
    raw = f"hyprl:{symbol}:{ts}:{decision}".encode("utf-8")
    h = hashlib.sha1(raw).hexdigest()
    safe_symbol = symbol.lower().replace("/", "-")
    return f"hyprl-{safe_symbol}-{h[:24]}"


def _to_enum(value: Any) -> Optional[str]:
    if value is None:
        return None
    if hasattr(value, "value"):
        return str(value.value)
    return str(value)


def _to_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _to_iso(value: Any) -> Optional[str]:
    if isinstance(value, datetime):
        return value.isoformat()
    return None


def order_to_dict(order: Any) -> Dict[str, Any]:
    if order is None:
        return {}
    return {
        "id": str(getattr(order, "id", "")) or None,
        "client_order_id": str(getattr(order, "client_order_id", "")) or None,
        "symbol": str(getattr(order, "symbol", "")) or None,
        "qty": _to_float(getattr(order, "qty", None)),
        "filled_qty": _to_float(getattr(order, "filled_qty", None)),
        "side": _to_enum(getattr(order, "side", None)),
        "order_type": _to_enum(getattr(order, "order_type", None)),
        "status": _to_enum(getattr(order, "status", None)),
        "time_in_force": _to_enum(getattr(order, "time_in_force", None)),
        "limit_price": _to_float(getattr(order, "limit_price", None)),
        "stop_price": _to_float(getattr(order, "stop_price", None)),
        "filled_avg_price": _to_float(getattr(order, "filled_avg_price", None)),
        "created_at": _to_iso(getattr(order, "created_at", None)),
        "updated_at": _to_iso(getattr(order, "updated_at", None)),
        "filled_at": _to_iso(getattr(order, "filled_at", None)),
        "canceled_at": _to_iso(getattr(order, "canceled_at", None)),
        "failed_at": _to_iso(getattr(order, "failed_at", None)),
        "asset_class": str(getattr(order, "asset_class", "")) or None,
    }


def position_to_dict(pos: Any) -> Dict[str, Any]:
    if pos is None:
        return {}
    return {
        "symbol": str(getattr(pos, "symbol", "")) or None,
        "side": str(getattr(pos, "side", "")) or None,
        "qty": _to_float(getattr(pos, "qty", None)),
        "entry_price": _to_float(getattr(pos, "entry_price", None)),
        "current_price": _to_float(getattr(pos, "current_price", None)),
        "market_value": _to_float(getattr(pos, "market_value", None)),
        "cost_basis": _to_float(getattr(pos, "cost_basis", None)),
        "unrealized_pnl": _to_float(getattr(pos, "unrealized_pnl", None)),
        "unrealized_pnl_pct": _to_float(getattr(pos, "unrealized_pnl_pct", None)),
        "asset_class": str(getattr(pos, "asset_class", "")) or None,
    }


def account_to_dict(acct: Any) -> Dict[str, Any]:
    if acct is None:
        return {}
    return {
        "equity": _to_float(getattr(acct, "equity", None)),
        "cash": _to_float(getattr(acct, "cash", None)),
        "buying_power": _to_float(getattr(acct, "buying_power", None)),
        "currency": str(getattr(acct, "currency", "")) or None,
        "status": str(getattr(acct, "status", "")) or None,
        "pattern_day_trader": bool(getattr(acct, "pattern_day_trader", False)),
        "trading_blocked": bool(getattr(acct, "trading_blocked", False)),
        "transfers_blocked": bool(getattr(acct, "transfers_blocked", False)),
    }


def is_bridge_order(order: Any, allowlist: Optional[Set[str]]) -> bool:
    if order is None:
        return False
    client_id = str(getattr(order, "client_order_id", "") or "")
    if not client_id.startswith("hyprl-"):
        return False
    symbol = str(getattr(order, "symbol", "") or "").upper()
    if allowlist is not None and symbol not in allowlist:
        return False
    return True


def normalize_pct(value: Optional[float]) -> Optional[float]:
    if value is None:
        return None
    try:
        pct = float(value)
    except (TypeError, ValueError):
        return None
    if pct < 0:
        return None
    return pct / 100.0 if pct > 1.0 else pct


def send_discord_alert(webhook: str, payload: Dict[str, Any]) -> None:
    if not webhook:
        return
    try:
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            webhook,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=5):
            pass
    except Exception:
        return


@dataclass
class BridgeState:
    file_offset: int = 0
    last_exec_ts_by_symbol: Dict[str, str] = None
    last_exec_decision_by_symbol: Dict[str, str] = None
    day: str = ""
    orders_today: int = 0
    notional_today: float = 0.0
    day_start_equity: Optional[float] = None
    last_positions_snapshot_at: str = ""
    order_notional_by_id: Dict[str, float] = None
    filled_order_ids: List[str] = None
    cooldown_until_by_symbol: Dict[str, str] = None
    daily_dd_stop_active: bool = False

    def __post_init__(self) -> None:
        if self.last_exec_ts_by_symbol is None:
            self.last_exec_ts_by_symbol = {}
        if self.last_exec_decision_by_symbol is None:
            self.last_exec_decision_by_symbol = {}
        if self.order_notional_by_id is None:
            self.order_notional_by_id = {}
        if self.filled_order_ids is None:
            self.filled_order_ids = []
        if self.cooldown_until_by_symbol is None:
            self.cooldown_until_by_symbol = {}


def load_state(path: Path) -> BridgeState:
    if not path.exists():
        return BridgeState()
    data = json.loads(path.read_text(encoding="utf-8"))
    return BridgeState(
        file_offset=int(data.get("file_offset", 0)),
        last_exec_ts_by_symbol=dict(data.get("last_exec_ts_by_symbol", {})),
        last_exec_decision_by_symbol=dict(data.get("last_exec_decision_by_symbol", {})),
        day=str(data.get("day", "")),
        orders_today=int(data.get("orders_today", 0) or 0),
        notional_today=float(data.get("notional_today", 0.0) or 0.0),
        day_start_equity=data.get("day_start_equity", None),
        last_positions_snapshot_at=str(data.get("last_positions_snapshot_at", "")),
        order_notional_by_id=dict(data.get("order_notional_by_id", {})),
        filled_order_ids=list(data.get("filled_order_ids", [])),
        cooldown_until_by_symbol=dict(data.get("cooldown_until_by_symbol", {})),
        daily_dd_stop_active=bool(data.get("daily_dd_stop_active", False)),
    )


def save_state(path: Path, st: BridgeState) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(asdict(st), indent=2, sort_keys=True)
    path.write_text(payload, encoding="utf-8")


def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj) + "\n")


def normalize_short_qty(qty: float) -> int | None:
    floored = int(math.floor(qty))
    return floored if floored >= 1 else None


CRYPTO_DEFAULT_SYMBOLS: tuple[str, ...] = ("BTC/USD", "ETH/USD")


def is_crypto_symbol(symbol: str) -> bool:
    return "/" in symbol


def compute_crypto_exposure(positions: List[Any]) -> tuple[float, Dict[str, float]]:
    total = 0.0
    per_symbol: Dict[str, float] = {}
    for p in positions:
        asset_class = str(getattr(p, "asset_class", "") or "").lower()
        symbol = str(getattr(p, "symbol", "") or "").upper()
        if asset_class == "crypto" and "/" not in symbol and symbol.endswith("USD") and len(symbol) > 3:
            symbol = f"{symbol[:-3]}/USD"
        if asset_class != "crypto" and "/" not in symbol:
            continue
        qty = _to_float(getattr(p, "qty", None)) or 0.0
        price = _to_float(getattr(p, "current_price", None)) or 0.0
        notional = abs(qty * price)
        total += notional
        if symbol:
            per_symbol[symbol] = notional
    return total, per_symbol


def _round_to_tick(price: float, tick: float, mode: str) -> float:
    if tick <= 0:
        return float(price)
    tick_dec = Decimal(str(tick))
    price_dec = Decimal(str(price))
    scaled = price_dec / tick_dec
    if mode == "ceil":
        scaled = scaled.to_integral_value(rounding=ROUND_CEILING)
    elif mode == "floor":
        scaled = scaled.to_integral_value(rounding=ROUND_FLOOR)
    else:
        scaled = scaled.to_integral_value()
    return float(scaled * tick_dec)


def adjust_bracket_prices(
    side: str,
    ref_price: float,
    stop_price: float,
    take_profit_price: float,
    min_offset: float = 0.01,
) -> tuple[float, float, bool]:
    adjusted = False
    ref_price = float(ref_price)
    stop_price = float(stop_price)
    take_profit_price = float(take_profit_price)

    if side == "long":
        min_tp = ref_price + min_offset
        max_sl = max(ref_price - min_offset, min_offset)
        if take_profit_price < min_tp:
            take_profit_price = min_tp
            adjusted = True
        if stop_price > max_sl:
            stop_price = max_sl
            adjusted = True
        if stop_price >= take_profit_price:
            stop_price = max_sl
            take_profit_price = min_tp
            adjusted = True
    else:
        max_tp = max(ref_price - min_offset, min_offset)
        min_sl = ref_price + min_offset
        if take_profit_price > max_tp:
            take_profit_price = max_tp
            adjusted = True
        if stop_price < min_sl:
            stop_price = min_sl
            adjusted = True
        if stop_price <= take_profit_price:
            stop_price = min_sl
            take_profit_price = max_tp
            adjusted = True

    tick = max(min_offset, 0.01)
    if side == "long":
        rounded_stop = _round_to_tick(stop_price, tick, "floor")
        rounded_tp = _round_to_tick(take_profit_price, tick, "ceil")
    else:
        rounded_stop = _round_to_tick(stop_price, tick, "ceil")
        rounded_tp = _round_to_tick(take_profit_price, tick, "floor")
    if rounded_stop != stop_price or rounded_tp != take_profit_price:
        adjusted = True
    stop_price, take_profit_price = rounded_stop, rounded_tp

    return stop_price, take_profit_price, adjusted


def _call_with_kwargs(fn: Any, kwargs: Dict[str, Any]) -> Any:
    sig = inspect.signature(fn)
    # If signature shows args/kwargs (decorated), pass all kwargs through
    if "args" in sig.parameters or "kwargs" in sig.parameters:
        accepted = {k: v for k, v in kwargs.items() if v is not None}
    else:
        accepted = {k: v for k, v in kwargs.items() if k in sig.parameters and v is not None}
    return fn(**accepted)


def call_submit_order(broker: Any, **kwargs: Any) -> Any:
    candidates = ["submit_order", "submit_market_order", "place_order"]
    last_err = None
    for name in candidates:
        if not hasattr(broker, name):
            continue
        fn = getattr(broker, name)
        try:
            return _call_with_kwargs(fn, kwargs)
        except Exception as exc:  # pragma: no cover - pass-through
            last_err = exc
            continue
    raise RuntimeError(f"Could not submit order via broker: {last_err}")


def call_submit_bracket(broker: Any, **kwargs: Any) -> Any:
    candidates = ["submit_bracket"]
    last_err = None
    for name in candidates:
        if not hasattr(broker, name):
            continue
        fn = getattr(broker, name)
        try:
            return _call_with_kwargs(fn, kwargs)
        except Exception as exc:  # pragma: no cover - pass-through
            last_err = exc
            continue
    if last_err is not None:
        raise RuntimeError(f"Could not submit bracket via broker: {last_err}")
    raise RuntimeError("Broker does not support submit_bracket")


def call_close_position(broker: Any, symbol: str) -> Any:
    if hasattr(broker, "close_position"):
        return broker.close_position(symbol)
    raise RuntimeError("Broker does not support close_position")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Alpaca bridge for core_v3 signal JSONL.")
    parser.add_argument("--signals", default="", help="Path to signal JSONL (append-only).")
    parser.add_argument(
        "--enable-crypto",
        action="store_true",
        help="Enable crypto mode (reads live/logs/crypto_signals.jsonl).",
    )
    parser.add_argument(
        "--crypto-signals",
        default="live/logs/crypto_signals.jsonl",
        help="Crypto signal JSONL path.",
    )
    parser.add_argument(
        "--max-crypto-allocation",
        type=float,
        default=0.20,
        help="Max crypto allocation as fraction or percent of equity (default: 0.20).",
    )
    parser.add_argument("--out", required=True, help="Execution journal JSONL output.")
    parser.add_argument("--state", required=True, help="State file (offset + last exec).")
    parser.add_argument("--symbols", default="", help="Comma-separated allowlist. Empty = allow all.")
    parser.add_argument("--paper", action="store_true", help="Use Alpaca paper trading.")
    parser.add_argument("--live", action="store_true", help="Use Alpaca live trading.")
    parser.add_argument("--dry-run", action="store_true", help="Log decisions without submitting orders.")
    parser.add_argument("--once", action="store_true", help="Process current lines then exit.")
    parser.add_argument(
        "--i-understand-live-orders",
        action="store_true",
        help="Required to run with --live.",
    )
    parser.add_argument(
        "--min-seconds-between-orders",
        type=int,
        default=3300,
        help="Cooldown per symbol (default: 55min).",
    )
    parser.add_argument(
        "--size-mode",
        choices=["shares", "notional"],
        default="shares",
        help="Interpret signal.size as shares or notional (default: shares).",
    )
    parser.add_argument("--max-notional-per-order", type=float, default=250.0)
    parser.add_argument("--min-notional-per-order", type=float, default=10.0)
    parser.add_argument("--max-orders-per-day", type=int, default=None)
    parser.add_argument("--max-notional-per-day", type=float, default=None)
    parser.add_argument("--kill-switch", default="", help="Path to kill-switch file.")
    parser.add_argument(
        "--kill-switch-poll-seconds",
        type=float,
        default=0.0,
        help="If >0, poll kill-switch file even when no new signals arrive.",
    )
    parser.add_argument("--max-qty", type=float, default=None)
    parser.add_argument("--allow-short", action="store_true", help="Allow short decisions.")
    parser.add_argument("--poll-seconds", type=float, default=0.25)
    parser.add_argument("--order-refresh-seconds", type=float, default=1.0)
    parser.add_argument("--positions-snapshot-seconds", type=float, default=0.0)
    parser.add_argument("--daily-report", default="", help="Daily report JSON path (default: alongside orders log).")
    parser.add_argument("--startup-refresh-max", type=int, default=5)
    parser.add_argument("--use-brackets", action="store_true", help="Use stop/take-profit brackets when available.")
    parser.add_argument("--block-on-unknown-notional", action="store_true")
    parser.add_argument("--max-notional-total", type=float, default=None)
    parser.add_argument("--max-notional-per-symbol", type=float, default=None)
    parser.add_argument("--max-open-positions", type=int, default=None)
    parser.add_argument("--cooldown-seconds", type=int, default=0)
    parser.add_argument("--cooldown-stale-seconds", type=int, default=0)
    parser.add_argument("--max-signal-age-seconds", type=int, default=0)
    parser.add_argument("--discord-webhook", default="")
    parser.add_argument("--max-daily-drawdown-pct", type=float, default=None)
    parser.add_argument("--skip-market-check", action="store_true")
    parser.add_argument(
        "--max-entry-slippage-pct",
        type=float,
        default=None,
        help="Max allowed slippage from signal entry_price (e.g., 0.3 for 0.3%%). Rejects if current price deviates more.",
    )
    parser.add_argument(
        "--skip-past-tp",
        action="store_true",
        help="Skip entry if current price already past take_profit target.",
    )
    parser.add_argument(
        "--use-limit-orders",
        action="store_true",
        help="Use LIMIT orders at entry_price instead of MARKET orders.",
    )
    parser.add_argument(
        "--limit-buffer-pct",
        type=float,
        default=0.1,
        help="Buffer above/below entry_price for limit orders (default 0.1%%).",
    )
    parser.add_argument(
        "--limit-timeout-seconds",
        type=float,
        default=120,
        help="Cancel unfilled limit order after this time (default 120s).",
    )
    parser.add_argument(
        "--poll-seconds-rth",
        type=float,
        default=None,
        help="Faster poll interval during RTH (9:30-16:00 ET). Falls back to --poll-seconds outside RTH.",
    )
    parser.add_argument(
        "--max-spread-pct",
        type=float,
        default=None,
        help="Max allowed spread %% to enter (e.g., 0.5 for 0.5%%). Rejects if spread too wide.",
    )
    parser.add_argument(
        "--close-eod-minutes",
        type=int,
        default=0,
        help="Close all positions N minutes before market close (0=disabled). E.g., 10 closes at 15:50 ET.",
    )
    # Strategy V3 (enhanced strategy with dynamic sizing, trailing stops, exits)
    parser.add_argument(
        "--enable-strategy-v3",
        action="store_true",
        help="Enable Strategy V3 (conviction sizing, trailing stops, partial exits, signal quality).",
    )
    parser.add_argument(
        "--v3-min-quality-score",
        type=float,
        default=0.6,
        help="Minimum signal quality score (0-1) for Strategy V3 (default: 0.6).",
    )
    parser.add_argument(
        "--v3-partial-r-levels",
        default="1.5,2.5",
        help="R-multiple levels for partial profit taking (default: 1.5,2.5).",
    )
    parser.add_argument(
        "--v3-stagnant-hours",
        type=int,
        default=6,
        help="Hours before exiting stagnant trades (default: 6).",
    )
    parser.add_argument(
        "--v3-trailing-atr-mult",
        type=float,
        default=2.0,
        help="ATR multiplier for trailing stops (default: 2.0).",
    )
    # Strategy Guards V2 (enhanced risk management)
    parser.add_argument(
        "--enable-guards-v2",
        action="store_true",
        help="Enable Strategy Guards V2 (calendar, correlation, regime, liquidity, options).",
    )
    parser.add_argument(
        "--disable-calendar-guard",
        action="store_true",
        help="Disable earnings/FOMC/OpEx calendar checks.",
    )
    parser.add_argument(
        "--disable-correlation-guard",
        action="store_true",
        help="Disable portfolio correlation limits.",
    )
    parser.add_argument(
        "--disable-regime-guard",
        action="store_true",
        help="Disable VIX/macro regime detection.",
    )
    parser.add_argument(
        "--disable-liquidity-guard",
        action="store_true",
        help="Disable liquidity-based sizing.",
    )
    parser.add_argument(
        "--disable-options-guard",
        action="store_true",
        help="Disable options flow analysis.",
    )
    parser.add_argument(
        "--earnings-blackout-days",
        type=int,
        default=3,
        help="Days before earnings to block trades (default: 3).",
    )
    parser.add_argument(
        "--max-correlated-notional",
        type=float,
        default=15000,
        help="Max notional in highly correlated positions (default: $15000).",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.live and not args.i_understand_live_orders:
        raise SystemExit("Refusing to run live without --i-understand-live-orders")

    allowlist: Optional[Set[str]] = None
    if args.symbols.strip():
        allowlist = {s.strip().upper() for s in args.symbols.split(",") if s.strip()}
    elif args.enable_crypto:
        allowlist = {s.upper() for s in CRYPTO_DEFAULT_SYMBOLS}

    if args.enable_crypto:
        signals_path = Path(args.crypto_signals)
    else:
        if not args.signals:
            raise SystemExit("Missing --signals (required unless --enable-crypto).")
        signals_path = Path(args.signals)
    out_path = Path(args.out)
    state_path = Path(args.state)

    st = load_state(state_path)

    from hyprl.broker.alpaca import AlpacaBroker
    from hyprl.broker import OrderSide, OrderType, TimeInForce

    paper = True if args.paper else False
    if args.live:
        paper = False
    broker = AlpacaBroker(paper=paper)

    # Initialize Strategy Guards V2 if enabled
    guards_v2 = None
    if args.enable_guards_v2:
        try:
            from hyprl.strategy.guards_v2 import StrategyGuardsV2
            guards_v2 = StrategyGuardsV2(
                symbols=list(allowlist) if allowlist else ["NVDA", "MSFT", "QQQ"],
                enable_calendar=not args.disable_calendar_guard,
                enable_correlation=not args.disable_correlation_guard,
                enable_regime=not args.disable_regime_guard,
                enable_liquidity=not args.disable_liquidity_guard,
                enable_options=not args.disable_options_guard,
                earnings_blackout_days=args.earnings_blackout_days,
                max_correlated_notional=args.max_correlated_notional,
            )
            append_jsonl(out_path, {
                "ts": utc_now_iso(),
                "event": "guards_v2_init",
                "calendar": not args.disable_calendar_guard,
                "correlation": not args.disable_correlation_guard,
                "regime": not args.disable_regime_guard,
                "liquidity": not args.disable_liquidity_guard,
                "options": not args.disable_options_guard,
            })
        except Exception as e:
            append_jsonl(out_path, {"ts": utc_now_iso(), "event": "guards_v2_init_failed", "error": str(e)})

    # Initialize Strategy V3 if enabled
    strategy_v3 = None
    if args.enable_strategy_v3:
        try:
            from hyprl.strategy.strategy_v3 import StrategyV3, StrategyV3Config
            from hyprl.strategy.sizing_v2 import SizingConfig
            from hyprl.strategy.trailing_v2 import TrailingConfig
            from hyprl.strategy.exits_v2 import ExitConfig
            from hyprl.strategy.signal_quality import QualityConfig

            # Parse partial R levels
            partial_r_levels = tuple(float(x) for x in args.v3_partial_r_levels.split(",") if x.strip())

            v3_config = StrategyV3Config(
                sizing=SizingConfig(),
                trailing=TrailingConfig(atr_multiplier=args.v3_trailing_atr_mult),
                exits=ExitConfig(
                    partial_r_levels=partial_r_levels,
                    stagnant_exit_hours=args.v3_stagnant_hours,
                ),
                quality=QualityConfig(min_quality_score=args.v3_min_quality_score),
            )
            strategy_v3 = StrategyV3(config=v3_config)
            append_jsonl(out_path, {
                "ts": utc_now_iso(),
                "event": "strategy_v3_init",
                "min_quality_score": args.v3_min_quality_score,
                "partial_r_levels": partial_r_levels,
                "stagnant_hours": args.v3_stagnant_hours,
                "trailing_atr_mult": args.v3_trailing_atr_mult,
            })
        except Exception as e:
            append_jsonl(out_path, {"ts": utc_now_iso(), "event": "strategy_v3_init_failed", "error": str(e)})

    append_jsonl(
        out_path,
        {
            "ts": utc_now_iso(),
            "event": "bridge_start",
            "signals": str(signals_path),
            "paper": paper,
            "crypto_mode": args.enable_crypto,
        },
    )

    # Wait for signals file to exist
    while not signals_path.exists():
        time.sleep(args.poll_seconds)

    report_path = Path(args.daily_report) if args.daily_report else out_path.parent / "daily_report.json"
    today_day = datetime.now(timezone.utc).date().isoformat()
    if st.day != today_day:
        st.day = today_day
        st.orders_today = 0
        st.notional_today = 0.0
        st.order_notional_by_id = {}
        st.filled_order_ids = []
        st.day_start_equity = None

    def record_day_start_equity() -> None:
        if not hasattr(broker, "get_account"):
            return
        try:
            acct = broker.get_account()
        except Exception as exc:
            append_jsonl(out_path, {"ts": utc_now_iso(), "event": "account_snapshot_failed", "error": str(exc)})
            return
        st.day_start_equity = _to_float(getattr(acct, "equity", None))

    def log_event(event: str, alert: bool = False, **fields: Any) -> None:
        payload = {"ts": utc_now_iso(), "event": event, **fields}
        append_jsonl(out_path, payload)
        if alert and args.discord_webhook:
            send_discord_alert(args.discord_webhook, {"content": json.dumps(payload, default=str)})

    crypto_allocation_frac = normalize_pct(args.max_crypto_allocation)
    if crypto_allocation_frac is None:
        crypto_allocation_frac = 0.20

    def compute_crypto_limits(symbol: str) -> Optional[Dict[str, float]]:
        if not hasattr(broker, "get_account") or not hasattr(broker, "list_positions"):
            log_event("crypto_allocation_missing_broker", symbol=symbol, alert=True)
            return None
        try:
            account = broker.get_account()
            equity = _to_float(getattr(account, "equity", None))
            if equity is None or equity <= 0:
                log_event("crypto_allocation_missing_equity", symbol=symbol, alert=True)
                return None
            positions = broker.list_positions()
        except Exception as exc:
            log_event("crypto_allocation_check_failed", symbol=symbol, error=str(exc), alert=True)
            return None
        total_exposure, per_symbol = compute_crypto_exposure(positions)
        symbol_exposure = per_symbol.get(symbol.upper(), 0.0)
        return {
            "equity": equity,
            "total_exposure": total_exposure,
            "symbol_exposure": symbol_exposure,
            "max_allocation": crypto_allocation_frac,
        }

    def cancel_open_orders_for_symbol(symbol: str, include_bracket_legs: bool = True) -> int:
        """Cancel all open orders for a symbol.

        Args:
            symbol: The symbol to cancel orders for
            include_bracket_legs: If True, cancel ALL orders including bracket legs (stop/TP).
                                  If False, only cancel orders with hyprl- prefix.
        """
        if not hasattr(broker, "list_orders") or not hasattr(broker, "cancel_order"):
            return 0
        try:
            orders = broker.list_orders(status="open", limit=500)
        except Exception as exc:
            log_event("cancel_orders_failed", symbol=symbol, error=str(exc))
            return 0
        canceled = 0
        for order in orders:
            order_symbol = str(getattr(order, "symbol", "") or "").upper()
            if order_symbol != symbol.upper():
                continue
            # If not including bracket legs, only cancel bridge orders
            if not include_bracket_legs and not is_bridge_order(order, allowlist):
                continue
            order_id = str(getattr(order, "id", "") or "")
            if not order_id:
                continue
            client_id = str(getattr(order, "client_order_id", "") or "")
            try:
                if broker.cancel_order(order_id):
                    canceled += 1
                    log_event("cancel_order_success", symbol=symbol, order_id=order_id, client_id=client_id[:30])
            except Exception as exc:
                log_event("cancel_order_failed", symbol=symbol, order_id=order_id, error=str(exc))
        if canceled:
            log_event("cancel_open_orders", symbol=symbol, canceled=canceled)
        return canceled

    max_dd_frac = normalize_pct(args.max_daily_drawdown_pct)
    if max_dd_frac is not None:
        log_event("daily_dd_config", max_daily_drawdown_frac=max_dd_frac, raw=args.max_daily_drawdown_pct)

    def set_cooldown(symbol: str, seconds: int, reason: str) -> None:
        if seconds <= 0:
            return
        existing = st.cooldown_until_by_symbol.get(symbol)
        if existing:
            try:
                if datetime.now(timezone.utc) < parse_ts(existing):
                    return
            except Exception:
                st.cooldown_until_by_symbol.pop(symbol, None)
        until_dt = datetime.now(timezone.utc) + timedelta(seconds=seconds)
        st.cooldown_until_by_symbol[symbol] = until_dt.isoformat()
        log_event("cooldown_set", symbol=symbol, until=until_dt.isoformat(), reason=reason)

    def backfill_notional_today() -> None:
        if st.notional_today > 0 or st.orders_today <= 0:
            return
        if not hasattr(broker, "list_orders"):
            return
        try:
            after = datetime.fromisoformat(st.day).replace(tzinfo=timezone.utc)
        except ValueError:
            return
        try:
            orders = broker.list_orders(status="all", limit=500, after=after)
        except Exception as exc:
            append_jsonl(out_path, {"ts": utc_now_iso(), "event": "notional_backfill_failed", "error": str(exc)})
            return
        total = 0.0
        filled_ids: List[str] = []
        for order in orders:
            if not is_bridge_order(order, allowlist):
                continue
            status = _to_enum(getattr(order, "status", None))
            if status != "filled":
                continue
            filled_qty = _to_float(getattr(order, "filled_qty", None)) or 0.0
            filled_avg = _to_float(getattr(order, "filled_avg_price", None))
            if filled_qty <= 0 or filled_avg is None:
                continue
            total += filled_qty * filled_avg
            order_id = str(getattr(order, "id", "") or "")
            if order_id:
                filled_ids.append(order_id)
        if total > 0:
            st.notional_today = float(total)
            st.filled_order_ids = list(set(st.filled_order_ids + filled_ids))
            log_event("notional_backfill", orders=len(filled_ids), notional_today=st.notional_today)

    def refresh_startup_orders() -> None:
        if args.startup_refresh_max <= 0:
            return
        if not st.filled_order_ids:
            return
        if not hasattr(broker, "get_order"):
            return
        seen = set()
        for order_id in st.filled_order_ids[: args.startup_refresh_max]:
            if order_id in seen:
                continue
            seen.add(order_id)
            try:
                order = broker.get_order(order_id)
            except Exception as exc:
                log_event("order_refresh_startup_failed", error=str(exc))
                continue
            if order is None:
                continue
            log_event("order_refresh_startup", order=order_to_dict(order))

    def fetch_order(order_id: Optional[str], client_id: Optional[str]) -> Any:
        if order_id and hasattr(broker, "get_order"):
            try:
                res = broker.get_order(order_id)
                if res is not None:
                    return res
            except Exception as exc:
                log_event("order_refresh_failed", error=str(exc))
        if client_id and hasattr(broker, "get_order_by_client_id"):
            try:
                return broker.get_order_by_client_id(client_id)
            except Exception as exc:
                log_event("order_refresh_failed", error=str(exc))
        return None

    def refresh_order(order: Any, fallback_price: Optional[float], context: str, track_notional: bool) -> None:
        if args.dry_run or order is None or args.order_refresh_seconds <= 0:
            return
        order_id = str(getattr(order, "id", "") or "")
        client_id = str(getattr(order, "client_order_id", "") or "")
        if not order_id and not client_id:
            return
        time.sleep(args.order_refresh_seconds)
        refreshed = fetch_order(order_id or None, client_id or None)
        if refreshed is None:
            return
        log_event("order_refresh", context=context, order=order_to_dict(refreshed))

        if not track_notional:
            return

        filled_qty = _to_float(getattr(refreshed, "filled_qty", None))
        filled_avg = _to_float(getattr(refreshed, "filled_avg_price", None))
        status = _to_enum(getattr(refreshed, "status", None))
        is_terminal = status in {"filled", "canceled", "rejected", "expired"}
        if not is_terminal:
            return
        if not order_id:
            return
        if order_id in st.filled_order_ids:
            return
        actual_notional = None
        if filled_qty is not None and filled_avg is not None:
            actual_notional = filled_qty * filled_avg
        elif filled_qty is not None and fallback_price is not None:
            actual_notional = filled_qty * fallback_price
        if actual_notional is None:
            log_event("notional_unknown", order_id=order_id, alert=True)
            if args.block_on_unknown_notional:
                log_event("unknown_notional_block", order_id=order_id, alert=True)
            return
        submitted = st.order_notional_by_id.pop(order_id, None)
        if submitted is not None:
            st.notional_today += float(actual_notional) - float(submitted)
        else:
            st.notional_today += float(actual_notional)
        st.filled_order_ids.append(order_id)

    def should_snapshot(now_dt: datetime) -> bool:
        if args.positions_snapshot_seconds <= 0:
            return True
        if not st.last_positions_snapshot_at:
            return True
        try:
            last_dt = parse_ts(st.last_positions_snapshot_at)
        except Exception:
            return True
        return (now_dt - last_dt).total_seconds() >= args.positions_snapshot_seconds

    def snapshot_positions_and_report(now_dt: datetime) -> None:
        if not should_snapshot(now_dt):
            return
        positions = []
        account = None
        if hasattr(broker, "list_positions"):
            try:
                positions = broker.list_positions()
            except Exception as exc:
                log_event("positions_snapshot_failed", error=str(exc))
        if hasattr(broker, "get_account"):
            try:
                account = broker.get_account()
            except Exception as exc:
                log_event("account_snapshot_failed", error=str(exc))

        pos_payload = [position_to_dict(p) for p in positions]
        log_event("positions_snapshot", positions=pos_payload)

        exposure = 0.0
        unrealized = 0.0
        for p in positions:
            qty = _to_float(getattr(p, "qty", None)) or 0.0
            price = _to_float(getattr(p, "current_price", None)) or 0.0
            exposure += abs(qty * price)
            unrealized += _to_float(getattr(p, "unrealized_pnl", None)) or 0.0

        equity = _to_float(getattr(account, "equity", None)) if account else None
        if st.day_start_equity is None and equity is not None:
            st.day_start_equity = equity
        total_pnl = None
        realized_pnl = None
        if equity is not None and st.day_start_equity is not None:
            total_pnl = equity - st.day_start_equity
            realized_pnl = total_pnl - unrealized
        daily_drawdown_pct = None
        if equity is not None and st.day_start_equity:
            daily_drawdown_pct = max(0.0, (st.day_start_equity - equity) / st.day_start_equity * 100.0)
            if max_dd_frac is not None and daily_drawdown_pct >= max_dd_frac * 100.0:
                if not st.daily_dd_stop_active:
                    st.daily_dd_stop_active = True
                    log_event(
                        "daily_dd_stop",
                        alert=True,
                        daily_drawdown_pct=daily_drawdown_pct,
                        threshold_pct=max_dd_frac * 100.0,
                    )

        report = {
            "ts": utc_now_iso(),
            "day": st.day,
            "account": account_to_dict(account),
            "equity_now": equity,
            "positions": pos_payload,
            "exposure_notional": exposure,
            "unrealized_pnl": unrealized,
            "realized_pnl": realized_pnl,
            "total_pnl": total_pnl,
            "daily_drawdown_pct": daily_drawdown_pct,
            "orders_today": st.orders_today,
            "notional_today": st.notional_today,
            "day_start_equity": st.day_start_equity,
        }
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
        if st.day:
            day_path = report_path.parent / f"daily_report_{st.day}.json"
            day_path.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
        st.last_positions_snapshot_at = now_dt.isoformat()

    backfill_notional_today()
    refresh_startup_orders()

    last_kill_check = datetime.now(timezone.utc)
    with signals_path.open("r", encoding="utf-8") as f:
        f.seek(st.file_offset, os.SEEK_SET)
        while True:
            if args.kill_switch and Path(args.kill_switch).exists():
                log_event("kill_switch_active", alert=True, path=args.kill_switch)
                break

            line = f.readline()
            if not line:
                if args.kill_switch_poll_seconds and args.kill_switch_poll_seconds > 0:
                    now_poll = datetime.now(timezone.utc)
                    if (now_poll - last_kill_check).total_seconds() >= args.kill_switch_poll_seconds:
                        last_kill_check = now_poll
                        if args.kill_switch and Path(args.kill_switch).exists():
                            log_event("kill_switch_active", alert=True, path=args.kill_switch)
                            break
                        if args.kill_switch and allowlist is not None:
                            for sym in sorted(allowlist):
                                symbol_kill = Path(f"{args.kill_switch}_{sym.replace('/', '_')}")
                                if symbol_kill.exists():
                                    log_event(
                                        "kill_switch_symbol_active",
                                        alert=True,
                                        symbol=sym,
                                        path=str(symbol_kill),
                                    )
                now_dt = datetime.now(timezone.utc)
                now_day = now_dt.date().isoformat()
                if st.day != now_day:
                    st.day = now_day
                    st.orders_today = 0
                    st.notional_today = 0.0
                    st.order_notional_by_id = {}
                    st.filled_order_ids = []
                    st.day_start_equity = None
                    st.eod_closed_today = False  # Reset EOD flag for new day
                if args.positions_snapshot_seconds > 0:
                    snapshot_positions_and_report(now_dt)

                # Strategy V3: Check position updates for trailing stops and partial exits
                if strategy_v3 is not None and hasattr(broker, "list_positions"):
                    try:
                        v3_positions = strategy_v3.get_all_positions()
                        if v3_positions:
                            broker_positions = broker.list_positions()
                            broker_pos_map = {str(getattr(p, "symbol", "")).upper(): p for p in broker_positions}

                            for sym, v3_state in v3_positions.items():
                                broker_pos = broker_pos_map.get(sym)
                                if broker_pos is None:
                                    # Position closed externally
                                    strategy_v3.close_position(sym)
                                    log_event("v3_position_external_close", symbol=sym)
                                    continue

                                current_price = _to_float(getattr(broker_pos, "current_price", None))
                                if current_price is None:
                                    continue

                                # Estimate ATR from entry/stop distance (fallback)
                                current_atr = abs(v3_state.entry_price - v3_state.initial_stop) / 2

                                update = strategy_v3.update_position(
                                    symbol=sym,
                                    current_price=current_price,
                                    current_atr=current_atr,
                                    now=now_dt,
                                )

                                if update.action == "close_all":
                                    log_event(
                                        "v3_exit_signal",
                                        alert=True,
                                        symbol=sym,
                                        action=update.action,
                                        qty=update.qty_to_close,
                                        reason=update.reason,
                                    )
                                    # Execute the exit
                                    if not args.dry_run:
                                        try:
                                            cancel_open_orders_for_symbol(sym)
                                            res = broker.close_position(sym)
                                            log_event("v3_exit_executed", symbol=sym, order=order_to_dict(res), reason=update.reason)
                                            strategy_v3.close_position(sym)
                                        except Exception as e:
                                            log_event("v3_exit_failed", symbol=sym, error=str(e))
                                elif update.action == "close_partial":
                                    log_event(
                                        "v3_partial_signal",
                                        alert=True,
                                        symbol=sym,
                                        action=update.action,
                                        qty=update.qty_to_close,
                                        reason=update.reason,
                                    )
                                    # Execute partial exit (sell some shares)
                                    if not args.dry_run and update.qty_to_close > 0:
                                        try:
                                            side = OrderSide.SELL if v3_state.is_long else OrderSide.BUY
                                            res = call_submit_order(
                                                broker,
                                                symbol=sym,
                                                qty=update.qty_to_close,
                                                side=side,
                                                order_type=OrderType.MARKET,
                                                time_in_force=TimeInForce.DAY,
                                            )
                                            log_event("v3_partial_executed", symbol=sym, qty=update.qty_to_close, order=order_to_dict(res), reason=update.reason)
                                        except Exception as e:
                                            log_event("v3_partial_failed", symbol=sym, error=str(e))
                                elif update.action == "update_stop":
                                    log_event(
                                        "v3_trailing_update",
                                        symbol=sym,
                                        new_stop=update.new_stop,
                                        reason=update.reason,
                                    )
                    except Exception as e:
                        log_event("v3_position_update_error", error=str(e))

                # EOD auto-close: close all positions N minutes before market close
                if args.close_eod_minutes and args.close_eod_minutes > 0:
                    mins_to_close = minutes_to_market_close()
                    if mins_to_close is not None and mins_to_close <= args.close_eod_minutes:
                        if not getattr(st, "eod_closed_today", False):
                            append_jsonl(out_path, {"ts": utc_now_iso(), "event": "eod_close_triggered", "minutes_to_close": mins_to_close})
                            try:
                                positions = broker.list_positions()
                                for pos in positions:
                                    sym = getattr(pos, "symbol", None)
                                    if sym:
                                        try:
                                            broker.cancel_open_orders(sym) if hasattr(broker, "cancel_open_orders") else None
                                        except Exception:
                                            pass
                                        try:
                                            res = broker.close_position(sym)
                                            append_jsonl(out_path, {"ts": utc_now_iso(), "event": "eod_close_position", "symbol": sym, "order": order_to_dict(res)})
                                        except Exception as e:
                                            append_jsonl(out_path, {"ts": utc_now_iso(), "event": "eod_close_error", "symbol": sym, "error": str(e)})
                            except Exception as e:
                                append_jsonl(out_path, {"ts": utc_now_iso(), "event": "eod_close_list_error", "error": str(e)})
                            st.eod_closed_today = True
                st.file_offset = f.tell()
                save_state(state_path, st)
                if args.once:
                    break
                # Use faster polling during RTH if configured
                sleep_seconds = args.poll_seconds
                if args.poll_seconds_rth is not None and is_rth_now():
                    sleep_seconds = args.poll_seconds_rth
                if args.kill_switch_poll_seconds and args.kill_switch_poll_seconds > 0:
                    sleep_seconds = min(sleep_seconds, args.kill_switch_poll_seconds)
                time.sleep(sleep_seconds)
                continue

            st.file_offset = f.tell()
            line = line.strip()
            if not line:
                continue

            try:
                ev = json.loads(line)
            except Exception as exc:
                append_jsonl(out_path, {"ts": utc_now_iso(), "event": "bad_json", "error": str(exc)})
                continue

            symbol = str(ev.get("symbol", "")).upper()
            if not symbol:
                continue
            if allowlist is not None and symbol not in allowlist:
                continue
            is_crypto = args.enable_crypto and (
                is_crypto_symbol(symbol) or str(ev.get("asset_class", "")).lower() == "crypto"
            )
            if args.kill_switch:
                symbol_kill = Path(f"{args.kill_switch}_{symbol.replace('/', '_')}")
                if symbol_kill.exists():
                    log_event("kill_switch_symbol_active", alert=True, symbol=symbol, path=str(symbol_kill))
                    continue

            ts = str(ev.get("timestamp", ""))
            decision = str(ev.get("decision") or ev.get("direction") or "").lower()
            if decision == "neutral":
                decision = "flat"
            size = float(ev.get("size", 0.0) or 0.0)
            size_pct = normalize_pct(ev.get("size_pct")) if args.enable_crypto else None
            if not ts or decision not in ("long", "short", "flat"):
                continue
            target = decision
            if target == "short" and not args.allow_short:
                target = "flat"
            if is_crypto and target == "short":
                log_event("crypto_short_disabled", symbol=symbol, decision=decision)
                target = "flat"
            event_day = parse_ts(ts).date().isoformat()
            if st.day != event_day:
                st.day = event_day
                st.orders_today = 0
                st.notional_today = 0.0
                st.order_notional_by_id = {}
                st.filled_order_ids = []
                st.day_start_equity = None
                record_day_start_equity()

            last_ts = st.last_exec_ts_by_symbol.get(symbol)
            last_dec = st.last_exec_decision_by_symbol.get(symbol)
            now_dt = parse_ts(ts)
            if args.max_signal_age_seconds and args.max_signal_age_seconds > 0:
                age_seconds = (datetime.now(timezone.utc) - now_dt).total_seconds()
                if age_seconds > args.max_signal_age_seconds:
                    cooldown_until = st.cooldown_until_by_symbol.get(symbol)
                    if cooldown_until:
                        try:
                            cooldown_dt = parse_ts(cooldown_until)
                            if datetime.now(timezone.utc) < cooldown_dt:
                                log_event(
                                    "cooldown_skip",
                                    symbol=symbol,
                                    until=cooldown_until,
                                    reason="stale_signal",
                                )
                                continue
                        except Exception:
                            st.cooldown_until_by_symbol.pop(symbol, None)
                    log_event(
                        "stale_signal_skip",
                        alert=True,
                        symbol=symbol,
                        age_seconds=age_seconds,
                        signal_ts=ts,
                    )
                    if args.cooldown_stale_seconds > 0:
                        set_cooldown(symbol, args.cooldown_stale_seconds, "stale_signal")
                    continue
            cooldown_until = st.cooldown_until_by_symbol.get(symbol)
            if cooldown_until:
                try:
                    cooldown_dt = parse_ts(cooldown_until)
                    if datetime.now(timezone.utc) < cooldown_dt:
                        log_event("cooldown_skip", symbol=symbol, until=cooldown_until)
                        continue
                except Exception:
                    st.cooldown_until_by_symbol.pop(symbol, None)
            if last_ts:
                last_dt = parse_ts(last_ts)
                if (now_dt - last_dt).total_seconds() < args.min_seconds_between_orders:
                    continue
                if last_dec == decision and (now_dt - last_dt).total_seconds() < 2 * args.min_seconds_between_orders:
                    continue
            if st.daily_dd_stop_active and decision != "flat":
                log_event("daily_dd_stop_skip", symbol=symbol, decision=decision)
                continue

            # Market guard
            if not args.skip_market_check and not is_crypto:
                try:
                    if hasattr(broker, "is_market_open") and not broker.is_market_open():
                        log_event("market_closed_skip", symbol=symbol)
                        continue
                except Exception as exc:
                    log_event("market_check_error", error=str(exc))

            pos = None
            if hasattr(broker, "get_position"):
                try:
                    pos = broker.get_position(symbol)
                except Exception:
                    pos = None

            size_mode = args.size_mode
            crypto_ctx = None
            if is_crypto:
                size_mode = "notional"
                if target in ("long", "short"):
                    crypto_ctx = compute_crypto_limits(symbol)
                    if crypto_ctx is None:
                        continue
                    if size_pct is not None:
                        size = crypto_ctx["equity"] * size_pct
                    if size <= 0:
                        log_event("crypto_missing_size", symbol=symbol, alert=True)
                        continue

            # Get signal entry price
            entry_price = _to_float(ev.get("entry_price"))

            # Fetch live quote (bid/ask) for accurate slippage check
            quote = None
            bid_price = None
            ask_price = None
            spread_pct = None
            if hasattr(broker, "get_latest_quote"):
                try:
                    quote = broker.get_latest_quote(symbol)
                    if quote:
                        bid_price = quote.get("bid")
                        ask_price = quote.get("ask")
                        spread_pct = quote.get("spread_pct")
                except Exception:
                    pass

            # Fallback to last trade price if no quote
            price = None
            if target == "long" and ask_price:
                price = ask_price  # LONG buys at ASK
            elif target == "short" and bid_price:
                price = bid_price  # SHORT sells at BID
            elif hasattr(broker, "get_latest_trade_price"):
                try:
                    price = broker.get_latest_trade_price(symbol)
                except Exception:
                    pass
            if price is None and entry_price is not None:
                price = entry_price

            # Spread guard: reject if spread too wide
            max_spread = normalize_pct(args.max_spread_pct)
            if max_spread is not None and spread_pct is not None and target in ("long", "short"):
                if spread_pct > max_spread * 100:
                    log_event(
                        "spread_reject",
                        alert=True,
                        symbol=symbol,
                        spread_pct=round(spread_pct, 3),
                        max_spread_pct=round(max_spread * 100, 3),
                        bid=bid_price,
                        ask=ask_price,
                    )
                    set_cooldown(symbol, args.cooldown_seconds, "spread_reject")
                    continue

            # Slippage check: reject if ref price deviates too much from signal entry_price
            # LONG: compare ASK vs entry_price (we buy at ASK)
            # SHORT: compare BID vs entry_price (we sell at BID)
            max_slip_pct = normalize_pct(args.max_entry_slippage_pct)
            if max_slip_pct is not None and entry_price is not None and price is not None:
                slip_pct = abs(price - entry_price) / entry_price
                if target == "long" and price > entry_price * (1 + max_slip_pct):
                    log_event(
                        "slippage_reject_long",
                        alert=True,
                        symbol=symbol,
                        entry_price=entry_price,
                        ref_price=price,
                        bid=bid_price,
                        ask=ask_price,
                        slippage_pct=round(slip_pct * 100, 3),
                        max_slippage_pct=round(max_slip_pct * 100, 3),
                    )
                    set_cooldown(symbol, args.cooldown_seconds, "slippage_reject")
                    continue
                elif target == "short" and price < entry_price * (1 - max_slip_pct):
                    log_event(
                        "slippage_reject_short",
                        alert=True,
                        symbol=symbol,
                        entry_price=entry_price,
                        ref_price=price,
                        bid=bid_price,
                        ask=ask_price,
                        slippage_pct=round(slip_pct * 100, 3),
                        max_slippage_pct=round(max_slip_pct * 100, 3),
                    )
                    set_cooldown(symbol, args.cooldown_seconds, "slippage_reject")
                    continue

            stop_price = _to_float(
                ev.get("stop_price") or ev.get("stop") or ev.get("stop_loss")
            )
            take_profit_price = _to_float(
                ev.get("take_profit_price") or ev.get("take_profit") or ev.get("tp")
            )
            trailing_activation = _to_float(ev.get("trailing_stop_activation_price"))
            trailing_distance = _to_float(ev.get("trailing_stop_distance_price"))

            # Skip if price already past take profit (trade would be pointless)
            # LONG: compare ASK >= TP (we buy at ASK)
            # SHORT: compare BID <= TP (we sell at BID)
            if args.skip_past_tp and price is not None and take_profit_price is not None:
                if target == "long" and price >= take_profit_price:
                    log_event(
                        "skip_past_tp_long",
                        alert=True,
                        symbol=symbol,
                        ref_price=price,
                        bid=bid_price,
                        ask=ask_price,
                        take_profit_price=take_profit_price,
                    )
                    set_cooldown(symbol, args.cooldown_seconds, "past_tp")
                    continue
                elif target == "short" and price <= take_profit_price:
                    log_event(
                        "skip_past_tp_short",
                        alert=True,
                        symbol=symbol,
                        ref_price=price,
                        bid=bid_price,
                        ask=ask_price,
                        take_profit_price=take_profit_price,
                    )
                    set_cooldown(symbol, args.cooldown_seconds, "past_tp")
                    continue

            # Strategy Guards V2 check (calendar, correlation, regime, liquidity, options)
            guards_v2_qty_adj = 1.0
            guards_v2_threshold_adj = 0.0
            if guards_v2 is not None and target in ("long", "short") and not is_crypto:
                try:
                    # Get current positions for correlation check
                    current_positions_for_guards = []
                    if hasattr(broker, "list_positions"):
                        try:
                            pos_list = broker.list_positions()
                            for p in pos_list:
                                p_sym = str(getattr(p, "symbol", "")).upper()
                                p_qty = _to_float(getattr(p, "qty", None)) or 0.0
                                p_price = _to_float(getattr(p, "current_price", None)) or 0.0
                                if p_sym and p_qty > 0:
                                    current_positions_for_guards.append({
                                        "symbol": p_sym,
                                        "notional": abs(p_qty * p_price),
                                    })
                        except Exception:
                            pass

                    # Get probability from signal if available
                    signal_prob = _to_float(ev.get("probability") or ev.get("prob")) or 0.5

                    # Run all guards
                    guard_result = guards_v2.check_all(
                        symbol=symbol,
                        decision=target,
                        requested_qty=int(size) if size > 0 else 1,
                        price=price or entry_price or 100,
                        probability=signal_prob,
                        current_positions=current_positions_for_guards,
                        current_spread_pct=spread_pct or 0,
                    )

                    # Log the guard check
                    log_event(
                        "guards_v2_check",
                        symbol=symbol,
                        decision=target,
                        allowed=guard_result["allowed"],
                        reject_reason=guard_result.get("reject_reason", ""),
                        threshold_adj=guard_result.get("threshold_adjustment", 0),
                        size_mult=guard_result.get("size_multiplier", 1.0),
                        adjusted_qty=guard_result.get("adjusted_qty"),
                        adjusted_prob=guard_result.get("adjusted_prob"),
                        checks=guard_result.get("checks", {}),
                    )

                    if not guard_result["allowed"]:
                        set_cooldown(symbol, args.cooldown_seconds, f"guards_v2:{guard_result['reject_reason']}")
                        continue

                    # Apply adjustments
                    guards_v2_qty_adj = guard_result.get("size_multiplier", 1.0)
                    guards_v2_threshold_adj = guard_result.get("threshold_adjustment", 0.0)

                except Exception as e:
                    log_event("guards_v2_error", symbol=symbol, error=str(e))

            # Strategy V3 signal quality check and dynamic sizing
            v3_qty_override = None
            if strategy_v3 is not None and target in ("long", "short") and not is_crypto:
                try:
                    # Get account equity for sizing
                    account_equity = 100_000  # Default
                    if hasattr(broker, "get_account"):
                        try:
                            acct = broker.get_account()
                            account_equity = _to_float(getattr(acct, "equity", None)) or 100_000
                        except Exception:
                            pass

                    # Get probability and ATR from signal
                    signal_prob = _to_float(ev.get("probability") or ev.get("prob")) or 0.6
                    signal_atr = _to_float(ev.get("atr")) or (abs(price - stop_price) if price and stop_price else 1.0)
                    avg_vol = _to_float(ev.get("avg_volume") or ev.get("volume_avg")) or 1_000_000
                    curr_vol = _to_float(ev.get("volume") or ev.get("current_volume")) or avg_vol

                    # Evaluate signal quality
                    v3_result = strategy_v3.evaluate_signal(
                        symbol=symbol,
                        probability=signal_prob,
                        threshold_long=0.60,  # Configurable
                        threshold_short=0.40,
                        entry_price=entry_price or price or 100,
                        stop_price=stop_price or (entry_price * 0.98 if entry_price else 98),
                        take_profit_price=take_profit_price or (entry_price * 1.04 if entry_price else 104),
                        equity=account_equity,
                        current_volume=curr_vol,
                        avg_volume=avg_vol,
                        atr=signal_atr,
                        bid=bid_price,
                        ask=ask_price,
                        regime_mult=guards_v2_qty_adj if guards_v2 else 1.0,
                    )

                    log_event(
                        "strategy_v3_eval",
                        symbol=symbol,
                        should_trade=v3_result.should_trade,
                        quality_score=round(v3_result.quality_score, 3),
                        recommended_size=v3_result.size,
                        reasons=v3_result.reasons,
                    )

                    if not v3_result.should_trade:
                        log_event(
                            "strategy_v3_reject",
                            symbol=symbol,
                            reasons=v3_result.reasons,
                            quality_score=round(v3_result.quality_score, 3),
                        )
                        set_cooldown(symbol, args.cooldown_seconds, f"v3:{v3_result.reasons[0] if v3_result.reasons else 'quality'}")
                        continue

                    # Use V3 dynamic sizing if signal size is 0 or unset
                    if v3_result.size > 0:
                        v3_qty_override = v3_result.size

                except Exception as e:
                    log_event("strategy_v3_error", symbol=symbol, error=str(e))

            def already_long(p) -> bool:
                return bool(p) and str(getattr(p, "side", "")) == "long"

            def already_short(p) -> bool:
                return bool(p) and str(getattr(p, "side", "")) == "short"

            use_brackets = args.use_brackets and not is_crypto
            order_tif = TimeInForce.GTC if is_crypto else TimeInForce.DAY

            client_order_id = stable_client_order_id(symbol, ts, target)
            did_submit = False
            order_notional: float | None = None
            refresh_ctx: Optional[str] = None
            refresh_order_obj: Any = None

            if target == "flat":
                if pos:
                    try:
                        if args.dry_run:
                            log_event("would_cancel_open_orders", symbol=symbol)
                            log_event("would_close", symbol=symbol)
                            did_submit = True
                        else:
                            cancel_open_orders_for_symbol(symbol)
                            res = call_close_position(broker, symbol)
                            log_event("close_position", symbol=symbol, order=order_to_dict(res))
                            did_submit = True
                            refresh_ctx = "close_position"
                            refresh_order_obj = res
                    except Exception as exc:
                        log_event("close_failed", alert=True, symbol=symbol, error=str(exc))
                        set_cooldown(symbol, args.cooldown_seconds, "close_failed")
                        continue
            elif target == "long":
                if already_long(pos):
                    continue
                if pos and already_short(pos):
                    try:
                        if args.dry_run:
                            log_event("would_cancel_open_orders", symbol=symbol)
                        else:
                            cancel_open_orders_for_symbol(symbol)
                        call_close_position(broker, symbol)
                    except Exception as exc:
                        log_event("flip_close_failed", alert=True, symbol=symbol, error=str(exc))
                        set_cooldown(symbol, args.cooldown_seconds, "flip_close_failed")
                        continue

                qty = max(0.0, size)
                # Apply Strategy V3 dynamic sizing if available
                if v3_qty_override is not None and v3_qty_override > 0:
                    qty = float(v3_qty_override)
                    log_event("v3_qty_override", symbol=symbol, original_size=size, v3_size=v3_qty_override)
                if size_mode == "notional":
                    if price is None:
                        append_jsonl(out_path, {"ts": utc_now_iso(), "event": "missing_price_notional", "symbol": symbol})
                        continue
                    cap = args.max_notional_per_order if args.max_notional_per_order is not None else size
                    order_notional = max(args.min_notional_per_order, min(size, cap))
                    qty = order_notional / price if price > 0 else 0.0
                elif price is not None:
                    order_notional = qty * price
                if args.max_qty is not None:
                    qty = min(qty, args.max_qty)
                # Apply Guards V2 size adjustment
                if guards_v2_qty_adj < 1.0:
                    original_qty = qty
                    qty = qty * guards_v2_qty_adj
                    if qty != original_qty:
                        log_event("guards_v2_size_adj", symbol=symbol, original_qty=original_qty, adjusted_qty=qty, multiplier=guards_v2_qty_adj)
                if is_crypto and price is not None:
                    order_notional = qty * price
                if is_crypto and crypto_ctx is not None:
                    if order_notional is None:
                        log_event("crypto_allocation_missing_notional", symbol=symbol, alert=True)
                        continue
                    total_exposure = crypto_ctx["total_exposure"]
                    symbol_exposure = crypto_ctx["symbol_exposure"]
                    effective_exposure = total_exposure
                    if pos and already_short(pos):
                        effective_exposure = max(0.0, total_exposure - symbol_exposure)
                    max_notional = crypto_ctx["equity"] * crypto_ctx["max_allocation"]
                    remaining = max_notional - effective_exposure
                    if remaining <= 0:
                        log_event(
                            "crypto_allocation_blocked",
                            symbol=symbol,
                            current_exposure=total_exposure,
                            max_allocation=max_notional,
                            alert=True,
                        )
                        continue
                    if order_notional > remaining:
                        if price is None or price <= 0:
                            log_event("crypto_allocation_missing_price", symbol=symbol, alert=True)
                            continue
                        qty = remaining / price
                        if qty <= 0:
                            log_event("crypto_allocation_qty_zero", symbol=symbol, alert=True)
                            continue
                        log_event(
                            "crypto_allocation_clipped",
                            symbol=symbol,
                            desired_notional=order_notional,
                            allowed_notional=remaining,
                        )
                        order_notional = remaining
                if qty <= 0:
                    continue
                if args.max_orders_per_day is not None and st.orders_today >= args.max_orders_per_day:
                    log_event("limit_orders_day", symbol=symbol, alert=True)
                    continue
                if args.max_notional_per_day is not None:
                    if order_notional is None:
                        log_event("missing_price_day_limit", symbol=symbol, alert=True)
                        continue
                    if (st.notional_today + order_notional) > args.max_notional_per_day:
                        log_event("limit_notional_day", symbol=symbol, alert=True)
                        continue
                if any(v is not None for v in (args.max_notional_total, args.max_notional_per_symbol, args.max_open_positions)):
                    if not hasattr(broker, "list_positions"):
                        log_event("positions_cap_check_failed", symbol=symbol, alert=True)
                        continue
                    try:
                        positions = broker.list_positions()
                    except Exception as exc:
                        log_event("positions_cap_check_failed", symbol=symbol, error=str(exc), alert=True)
                        continue
                    total_exposure = 0.0
                    per_symbol = {}
                    for p in positions:
                        qty_p = _to_float(getattr(p, "qty", None)) or 0.0
                        price_p = _to_float(getattr(p, "current_price", None)) or 0.0
                        notional_p = abs(qty_p * price_p)
                        total_exposure += notional_p
                        per_symbol[str(getattr(p, "symbol", "")).upper()] = notional_p
                    if args.max_open_positions is not None:
                        open_positions = len(positions)
                        if not pos and open_positions >= args.max_open_positions:
                            log_event("blocked_positions_cap", symbol=symbol, alert=True)
                            continue
                    if order_notional is None:
                        if price is None:
                            log_event("missing_price_notional_cap", symbol=symbol, alert=True)
                            continue
                        order_notional = qty * price
                    current_symbol = per_symbol.get(symbol, 0.0)
                    desired_notional = order_notional
                    remaining_total = (
                        args.max_notional_total - total_exposure
                        if args.max_notional_total is not None
                        else desired_notional
                    )
                    remaining_symbol = (
                        args.max_notional_per_symbol - current_symbol
                        if args.max_notional_per_symbol is not None
                        else desired_notional
                    )
                    allowed_notional = min(desired_notional, remaining_total, remaining_symbol)
                    if allowed_notional <= 0:
                        if args.max_notional_total is not None and remaining_total <= 0:
                            log_event("blocked_notional_total_cap", symbol=symbol, alert=True)
                        elif args.max_notional_per_symbol is not None and remaining_symbol <= 0:
                            log_event("blocked_notional_symbol_cap", symbol=symbol, alert=True)
                        else:
                            log_event("blocked_notional_cap", symbol=symbol, alert=True)
                        continue
                    if allowed_notional < desired_notional:
                        qty = allowed_notional / price if price and price > 0 else 0.0
                        if qty <= 0:
                            log_event(
                                "blocked_notional_cap_qty0",
                                symbol=symbol,
                                allowed_notional=allowed_notional,
                                price=price,
                                alert=True,
                            )
                            continue
                        log_event(
                            "clipped_by_cap",
                            symbol=symbol,
                            desired_qty=qty if price is None else desired_notional / price,
                            clipped_qty=qty,
                            desired_notional=desired_notional,
                            allowed_notional=allowed_notional,
                        )
                        order_notional = allowed_notional

                if use_brackets:
                    qty_int = int(math.floor(qty))
                    if abs(qty - qty_int) > 1e-8:
                        if qty_int < 1:
                            log_event("blocked_bracket_qty_lt_1", symbol=symbol, qty=qty, alert=True)
                            continue
                        log_event("bracket_qty_floor", symbol=symbol, qty=qty, qty_floor=qty_int)
                        qty = float(qty_int)
                        if price is not None:
                            order_notional = qty * price

                try:
                    if args.dry_run:
                        if use_brackets and stop_price is not None and take_profit_price is not None:
                            log_event(
                                "would_open_long_bracket",
                                symbol=symbol,
                                qty=qty,
                                stop_price=stop_price,
                                take_profit_price=take_profit_price,
                            )
                        else:
                            log_event("would_open_long", symbol=symbol, qty=qty)
                        did_submit = True
                    else:
                        if use_brackets:
                            if stop_price is None or take_profit_price is None:
                                log_event(
                                    "bracket_missing_exit",
                                    symbol=symbol,
                                    stop_price=stop_price,
                                    take_profit_price=take_profit_price,
                                    alert=True,
                                )
                                continue
                            if price is None:
                                log_event("bracket_missing_price", symbol=symbol, alert=True)
                                continue
                            if trailing_activation is not None or trailing_distance is not None:
                                log_event(
                                    "trailing_ignored",
                                    symbol=symbol,
                                    trailing_activation=trailing_activation,
                                    trailing_distance=trailing_distance,
                                )
                            ref_price = float(price)
                            stop_adj = float(stop_price)
                            tp_adj = float(take_profit_price)
                            if entry_price is not None:
                                delta = ref_price - float(entry_price)
                                if abs(delta) >= 0.0001:
                                    stop_adj = float(stop_price) + delta
                                    tp_adj = float(take_profit_price) + delta
                                    log_event(
                                        "bracket_price_shift",
                                        symbol=symbol,
                                        entry_price=entry_price,
                                        ref_price=ref_price,
                                        stop_price=stop_price,
                                        take_profit_price=take_profit_price,
                                        stop_price_adj=stop_adj,
                                        take_profit_price_adj=tp_adj,
                                    )
                            stop_adj, tp_adj, adjusted = adjust_bracket_prices(
                                "long", ref_price, stop_adj, tp_adj
                            )
                            if adjusted:
                                log_event(
                                    "bracket_price_adjusted",
                                    symbol=symbol,
                                    ref_price=ref_price,
                                    stop_price=stop_adj,
                                    take_profit_price=tp_adj,
                                )
                            res = call_submit_bracket(
                                broker,
                                symbol=symbol,
                                qty=qty,
                                side=OrderSide.BUY,
                                take_profit=tp_adj,
                                stop_loss=stop_adj,
                                time_in_force=TimeInForce.GTC,  # GTC to prevent bracket expiry
                                client_order_id=client_order_id,
                            )
                            log_event(
                                "open_long_bracket",
                                symbol=symbol,
                                qty=qty,
                                stop_price=stop_adj,
                                take_profit_price=tp_adj,
                                order=order_to_dict(res),
                            )
                            refresh_ctx = "open_long_bracket"
                            refresh_order_obj = res
                            did_submit = True
                        else:
                            # Use LIMIT orders if enabled, otherwise MARKET
                            if args.use_limit_orders and entry_price is not None:
                                buffer_pct = normalize_pct(args.limit_buffer_pct) or 0.001
                                limit_price = round(entry_price * (1 + buffer_pct), 2)
                                res = call_submit_order(
                                    broker,
                                    symbol=symbol,
                                    qty=qty,
                                    side=OrderSide.BUY,
                                    order_type=OrderType.LIMIT,
                                    limit_price=limit_price,
                                    time_in_force=order_tif,
                                    client_order_id=client_order_id,
                                )
                                log_event(
                                    "open_long_limit",
                                    symbol=symbol,
                                    qty=qty,
                                    limit_price=limit_price,
                                    entry_price=entry_price,
                                    order=order_to_dict(res),
                                )
                                refresh_ctx = "open_long_limit"
                            else:
                                # For crypto, use notional (dollar amount) with minimum $10
                                crypto_notional = None
                                if is_crypto and order_notional is not None:
                                    crypto_notional = max(order_notional, 10.0)
                                res = call_submit_order(
                                    broker,
                                    symbol=symbol,
                                    qty=qty,
                                    side=OrderSide.BUY,
                                    order_type=OrderType.MARKET,
                                    time_in_force=order_tif,
                                    client_order_id=client_order_id,
                                    notional=crypto_notional,
                                )
                                log_event("open_long", symbol=symbol, qty=qty, notional=crypto_notional, order=order_to_dict(res))
                                refresh_ctx = "open_long"
                            refresh_order_obj = res
                            did_submit = True
                except Exception as exc:
                    log_event("order_failed", alert=True, symbol=symbol, error=str(exc))
                    set_cooldown(symbol, args.cooldown_seconds, "order_failed")
                    continue
            else:
                if already_short(pos):
                    continue
                if pos and already_long(pos):
                    pos_qty = float(getattr(pos, "qty", 0.0) or 0.0)
                    try:
                        if args.dry_run:
                            log_event("would_cancel_open_orders", symbol=symbol)
                            log_event("would_close_long_before_short", symbol=symbol, qty=pos_qty)
                        else:
                            cancel_open_orders_for_symbol(symbol)
                            res = call_close_position(broker, symbol)
                            log_event("close_long_before_short", symbol=symbol, qty=pos_qty, order=order_to_dict(res))
                        did_submit = True
                        refresh_ctx = "close_long_before_short"
                        refresh_order_obj = res
                    except Exception as exc:
                        log_event("flip_close_failed", alert=True, symbol=symbol, error=str(exc))
                        set_cooldown(symbol, args.cooldown_seconds, "flip_close_failed")
                        continue
                    st.last_exec_ts_by_symbol[symbol] = ts
                    st.last_exec_decision_by_symbol[symbol] = "close_long_before_short"
                    if not args.dry_run:
                        st.orders_today += 1
                        if st.day_start_equity is None:
                            record_day_start_equity()
                    if refresh_order_obj is not None:
                        refresh_order(refresh_order_obj, price, refresh_ctx or "close_long_before_short", False)
                    snapshot_positions_and_report(datetime.now(timezone.utc))
                    save_state(state_path, st)
                    continue

                qty_raw = max(0.0, size)
                # Apply Strategy V3 dynamic sizing if available (shorts)
                if v3_qty_override is not None and v3_qty_override > 0:
                    qty_raw = float(v3_qty_override)
                    log_event("v3_qty_override", symbol=symbol, original_size=size, v3_size=v3_qty_override)
                if size_mode == "notional":
                    if price is None:
                        append_jsonl(out_path, {"ts": utc_now_iso(), "event": "missing_price_notional_short", "symbol": symbol})
                        continue
                    cap = args.max_notional_per_order if args.max_notional_per_order is not None else qty_raw
                    order_notional = min(qty_raw, cap)
                    qty_raw = order_notional / price if price > 0 else 0.0
                elif price is not None:
                    order_notional = qty_raw * price

                if args.max_qty is not None:
                    qty_raw = min(qty_raw, args.max_qty)
                # Apply Guards V2 size adjustment for shorts
                if guards_v2_qty_adj < 1.0:
                    original_qty = qty_raw
                    qty_raw = qty_raw * guards_v2_qty_adj
                    if qty_raw != original_qty:
                        log_event("guards_v2_size_adj", symbol=symbol, original_qty=original_qty, adjusted_qty=qty_raw, multiplier=guards_v2_qty_adj)
                if is_crypto and price is not None:
                    order_notional = qty_raw * price
                if is_crypto and crypto_ctx is not None:
                    if order_notional is None:
                        log_event("crypto_allocation_missing_notional", symbol=symbol, alert=True)
                        continue
                    total_exposure = crypto_ctx["total_exposure"]
                    symbol_exposure = crypto_ctx["symbol_exposure"]
                    effective_exposure = total_exposure
                    if pos and already_long(pos):
                        effective_exposure = max(0.0, total_exposure - symbol_exposure)
                    max_notional = crypto_ctx["equity"] * crypto_ctx["max_allocation"]
                    remaining = max_notional - effective_exposure
                    if remaining <= 0:
                        log_event(
                            "crypto_allocation_blocked",
                            symbol=symbol,
                            current_exposure=total_exposure,
                            max_allocation=max_notional,
                            alert=True,
                        )
                        continue
                    if order_notional > remaining:
                        if price is None or price <= 0:
                            log_event("crypto_allocation_missing_price", symbol=symbol, alert=True)
                            continue
                        qty_raw = remaining / price
                        if qty_raw <= 0:
                            log_event("crypto_allocation_qty_zero", symbol=symbol, alert=True)
                            continue
                        log_event(
                            "crypto_allocation_clipped",
                            symbol=symbol,
                            desired_notional=order_notional,
                            allowed_notional=remaining,
                        )
                        order_notional = remaining
                if args.max_orders_per_day is not None and st.orders_today >= args.max_orders_per_day:
                    log_event("limit_orders_day", symbol=symbol, alert=True)
                    continue
                if args.max_notional_per_day is not None:
                    if order_notional is None:
                        log_event("missing_price_day_limit", symbol=symbol, alert=True)
                        continue
                    if (st.notional_today + order_notional) > args.max_notional_per_day:
                        log_event("limit_notional_day", symbol=symbol, alert=True)
                        continue
                if any(v is not None for v in (args.max_notional_total, args.max_notional_per_symbol, args.max_open_positions)):
                    if not hasattr(broker, "list_positions"):
                        log_event("positions_cap_check_failed", symbol=symbol, alert=True)
                        continue
                    try:
                        positions = broker.list_positions()
                    except Exception as exc:
                        log_event("positions_cap_check_failed", symbol=symbol, error=str(exc), alert=True)
                        continue
                    total_exposure = 0.0
                    per_symbol = {}
                    for p in positions:
                        qty_p = _to_float(getattr(p, "qty", None)) or 0.0
                        price_p = _to_float(getattr(p, "current_price", None)) or 0.0
                        notional_p = abs(qty_p * price_p)
                        total_exposure += notional_p
                        per_symbol[str(getattr(p, "symbol", "")).upper()] = notional_p
                    if args.max_open_positions is not None:
                        open_positions = len(positions)
                        if not pos and open_positions >= args.max_open_positions:
                            log_event("blocked_positions_cap", symbol=symbol, alert=True)
                            continue
                    if order_notional is None:
                        if price is None:
                            log_event("missing_price_notional_cap", symbol=symbol, alert=True)
                            continue
                        order_notional = qty_raw * price
                    current_symbol = per_symbol.get(symbol, 0.0)
                    desired_notional = order_notional
                    remaining_total = (
                        args.max_notional_total - total_exposure
                        if args.max_notional_total is not None
                        else desired_notional
                    )
                    remaining_symbol = (
                        args.max_notional_per_symbol - current_symbol
                        if args.max_notional_per_symbol is not None
                        else desired_notional
                    )
                    allowed_notional = min(desired_notional, remaining_total, remaining_symbol)
                    if allowed_notional <= 0:
                        if args.max_notional_total is not None and remaining_total <= 0:
                            log_event("blocked_notional_total_cap", symbol=symbol, alert=True)
                        elif args.max_notional_per_symbol is not None and remaining_symbol <= 0:
                            log_event("blocked_notional_symbol_cap", symbol=symbol, alert=True)
                        else:
                            log_event("blocked_notional_cap", symbol=symbol, alert=True)
                        continue
                    if allowed_notional < desired_notional:
                        qty_raw = allowed_notional / price if price and price > 0 else 0.0
                        if qty_raw <= 0:
                            log_event(
                                "blocked_notional_cap_qty0",
                                symbol=symbol,
                                allowed_notional=allowed_notional,
                                price=price,
                                alert=True,
                            )
                            continue
                        log_event(
                            "clipped_by_cap",
                            symbol=symbol,
                            desired_qty=desired_notional / price if price else None,
                            clipped_qty=qty_raw,
                            desired_notional=desired_notional,
                            allowed_notional=allowed_notional,
                        )
                        order_notional = allowed_notional

                if is_crypto:
                    qty = qty_raw
                    if qty <= 0:
                        log_event("blocked_crypto_qty_le_zero", symbol=symbol, qty_calc=qty_raw, alert=True)
                        continue
                else:
                    qty_int = normalize_short_qty(qty_raw)
                    if qty_int is None:
                        log_event("blocked_short_qty_lt_1", symbol=symbol, qty_calc=qty_raw, alert=True)
                        continue
                    qty = qty_int
                if price is not None:
                    order_notional = qty * price

                try:
                    if args.dry_run:
                        if use_brackets and stop_price is not None and take_profit_price is not None:
                            log_event(
                                "would_open_short_bracket",
                                symbol=symbol,
                                qty=qty,
                                stop_price=stop_price,
                                take_profit_price=take_profit_price,
                            )
                        else:
                            log_event("would_open_short", symbol=symbol, qty=qty)
                        did_submit = True
                    else:
                        if use_brackets:
                            if stop_price is None or take_profit_price is None:
                                log_event(
                                    "bracket_missing_exit",
                                    symbol=symbol,
                                    stop_price=stop_price,
                                    take_profit_price=take_profit_price,
                                    alert=True,
                                )
                                continue
                            if price is None:
                                log_event("bracket_missing_price", symbol=symbol, alert=True)
                                continue
                            if trailing_activation is not None or trailing_distance is not None:
                                log_event(
                                    "trailing_ignored",
                                    symbol=symbol,
                                    trailing_activation=trailing_activation,
                                    trailing_distance=trailing_distance,
                                )
                            ref_price = float(price)
                            stop_adj = float(stop_price)
                            tp_adj = float(take_profit_price)
                            if entry_price is not None:
                                delta = ref_price - float(entry_price)
                                if abs(delta) >= 0.0001:
                                    stop_adj = float(stop_price) + delta
                                    tp_adj = float(take_profit_price) + delta
                                    log_event(
                                        "bracket_price_shift",
                                        symbol=symbol,
                                        entry_price=entry_price,
                                        ref_price=ref_price,
                                        stop_price=stop_price,
                                        take_profit_price=take_profit_price,
                                        stop_price_adj=stop_adj,
                                        take_profit_price_adj=tp_adj,
                                    )
                            stop_adj, tp_adj, adjusted = adjust_bracket_prices(
                                "short", ref_price, stop_adj, tp_adj
                            )
                            if adjusted:
                                log_event(
                                    "bracket_price_adjusted",
                                    symbol=symbol,
                                    ref_price=ref_price,
                                    stop_price=stop_adj,
                                    take_profit_price=tp_adj,
                                )
                            res = call_submit_bracket(
                                broker,
                                symbol=symbol,
                                qty=qty,
                                side=OrderSide.SELL,
                                take_profit=tp_adj,
                                stop_loss=stop_adj,
                                time_in_force=TimeInForce.GTC,  # GTC to prevent bracket expiry
                                client_order_id=client_order_id,
                            )
                            log_event(
                                "open_short_bracket",
                                symbol=symbol,
                                qty=qty,
                                stop_price=stop_adj,
                                take_profit_price=tp_adj,
                                order=order_to_dict(res),
                            )
                            refresh_ctx = "open_short_bracket"
                            refresh_order_obj = res
                            did_submit = True
                        else:
                            # Use LIMIT orders if enabled, otherwise MARKET
                            if args.use_limit_orders and entry_price is not None:
                                buffer_pct = normalize_pct(args.limit_buffer_pct) or 0.001
                                limit_price = round(entry_price * (1 - buffer_pct), 2)
                                res = call_submit_order(
                                    broker,
                                    symbol=symbol,
                                    qty=qty,
                                    side=OrderSide.SELL,
                                    order_type=OrderType.LIMIT,
                                    limit_price=limit_price,
                                    time_in_force=order_tif,
                                    client_order_id=client_order_id,
                                )
                                log_event(
                                    "open_short_limit",
                                    symbol=symbol,
                                    qty=qty,
                                    limit_price=limit_price,
                                    entry_price=entry_price,
                                    order=order_to_dict(res),
                                )
                                refresh_ctx = "open_short_limit"
                            else:
                                # For crypto, use notional (dollar amount) with minimum $10
                                crypto_notional = None
                                if is_crypto and order_notional is not None:
                                    crypto_notional = max(order_notional, 10.0)
                                res = call_submit_order(
                                    broker,
                                    symbol=symbol,
                                    qty=qty,
                                    side=OrderSide.SELL,
                                    order_type=OrderType.MARKET,
                                    time_in_force=order_tif,
                                    client_order_id=client_order_id,
                                    notional=crypto_notional,
                                )
                                log_event("open_short", symbol=symbol, qty=qty, notional=crypto_notional, order=order_to_dict(res))
                                refresh_ctx = "open_short"
                            refresh_order_obj = res
                            did_submit = True
                except Exception as exc:
                    log_event("order_failed", alert=True, symbol=symbol, error=str(exc))
                    set_cooldown(symbol, args.cooldown_seconds, "order_failed")
                    continue

            st.last_exec_ts_by_symbol[symbol] = ts
            st.last_exec_decision_by_symbol[symbol] = decision
            if did_submit and not args.dry_run:
                st.orders_today += 1
                if order_notional is not None:
                    st.notional_today += float(order_notional)
                    if refresh_order_obj is not None:
                        order_id = str(getattr(refresh_order_obj, "id", "") or "")
                        if order_id:
                            st.order_notional_by_id[order_id] = float(order_notional)
                if st.day_start_equity is None:
                    record_day_start_equity()
            if refresh_order_obj is not None:
                track_notional = refresh_ctx in {"open_long", "open_short"}
                refresh_order(refresh_order_obj, price, refresh_ctx or "submit", track_notional)

            # Register position with Strategy V3 for trailing/exit tracking
            if strategy_v3 is not None and did_submit and target in ("long", "short") and not is_crypto:
                try:
                    final_qty = int(qty) if target == "long" else int(qty_raw if 'qty_raw' in dir() else qty)
                    final_entry = entry_price or price or 100.0
                    final_stop = stop_price or (final_entry * 0.98 if target == "long" else final_entry * 1.02)
                    strategy_v3.register_position(
                        symbol=symbol,
                        entry_price=final_entry,
                        stop_price=final_stop,
                        qty=final_qty,
                        is_long=(target == "long"),
                    )
                    log_event(
                        "v3_position_registered",
                        symbol=symbol,
                        entry_price=final_entry,
                        stop_price=final_stop,
                        qty=final_qty,
                        is_long=(target == "long"),
                    )
                except Exception as e:
                    log_event("v3_position_register_failed", symbol=symbol, error=str(e))

            # Clean up Strategy V3 position on flat
            if strategy_v3 is not None and target == "flat" and not is_crypto:
                try:
                    strategy_v3.close_position(symbol)
                    log_event("v3_position_closed", symbol=symbol)
                except Exception:
                    pass

            snapshot_positions_and_report(datetime.now(timezone.utc))
            save_state(state_path, st)


if __name__ == "__main__":
    main()
