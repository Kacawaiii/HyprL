from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Literal, Optional

import pandas as pd
import yfinance as yf

logger = logging.getLogger(__name__)

_DEFAULT_YF_CACHE_DIR = Path("/tmp/hyprl-yfinance")
_DEFAULT_PRICE_CACHE_DIR = Path("data/cache/prices")
_YF_CACHE_DIR: Path
_CACHE_ROOT = Path(os.environ.get("HYPRL_PRICE_CACHE_DIR", _DEFAULT_PRICE_CACHE_DIR)).expanduser()
_CACHE_ROOT.mkdir(parents=True, exist_ok=True)
_CACHE_MAX_AGE = int(os.environ.get("HYPRL_PRICE_CACHE_MAX_AGE", 24 * 3600))


def configure_yfinance_cache_dir(cache_dir: Optional[str | Path] = None) -> Path:
    """
    Configure the directory used by yfinance for timezone cache files.
    """
    resolved = Path(cache_dir or os.environ.get("HYPRL_YFINANCE_CACHE_DIR") or _DEFAULT_YF_CACHE_DIR).expanduser()
    resolved.mkdir(parents=True, exist_ok=True)
    yf.set_tz_cache_location(str(resolved))
    global _YF_CACHE_DIR
    _YF_CACHE_DIR = resolved
    return resolved


configure_yfinance_cache_dir()

Interval = Literal["1m", "2m", "5m", "15m", "30m", "60m", "90m", "1h", "1d"]


def _cache_file(ticker: str, interval: str, period: Optional[str], start: Optional[str], end: Optional[str]) -> Path:
    suffix = period if not (start or end) else f"{start or 'none'}_{end or 'none'}"
    safe_suffix = str(suffix).replace("/", "-").replace(":", "-")
    return _CACHE_ROOT / ticker.upper() / interval / f"{safe_suffix}.csv"


def _read_cache(path: Path) -> Optional[pd.DataFrame]:
    if not path.exists():
        return None
    try:
        df = pd.read_csv(path, index_col=0, parse_dates=True)
    except Exception as exc:  # pragma: no cover
        logger.warning("Failed to read cache %s: %s", path, exc)
        return None
    df.index = pd.to_datetime(df.index, utc=True)
    return df


def _save_cache(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, date_format="%Y-%m-%dT%H:%M:%S%z")


def _read_latest_cache(ticker: str, interval: str) -> Optional[pd.DataFrame]:
    """Best-effort fallback to the newest cached CSV when a specific window is unavailable."""
    base = _CACHE_ROOT / ticker.upper() / interval
    if not base.exists():
        return None
    candidates = sorted(base.glob("*.csv"), key=lambda p: p.stat().st_mtime, reverse=True)
    for path in candidates:
        cached = _read_cache(path)
        if cached is not None and not cached.empty:
            return cached
    return None


def _fallback_cache(cache_path: Path, ticker: str, interval: str) -> Optional[pd.DataFrame]:
    """
    Return a non-empty cached dataframe if available, avoiding DataFrame truthiness ambiguity.
    """
    cached = _read_cache(cache_path)
    if cached is not None and not cached.empty:
        return cached
    latest = _read_latest_cache(ticker, interval)
    if latest is not None and not latest.empty:
        return latest
    return None


def _covers_window(df: pd.DataFrame, start: Optional[str], end: Optional[str]) -> bool:
    """
    Check that a DataFrame spans the requested window. Used to avoid returning a mismatched
    cache when explicit start/end are supplied.
    """
    if df.empty:
        return False
    index = df.index
    if index.tz is None:
        index = index.tz_localize("UTC", ambiguous="NaT", nonexistent="NaT")
    else:
        index = index.tz_convert("UTC")
    if start:
        start_ts = pd.to_datetime(start, utc=True)
        if index.max() < start_ts:
            return False
    if end:
        end_ts = pd.to_datetime(end, utc=True)
        if index.min() > end_ts:
            return False
    return True


def _filter_window(df: pd.DataFrame, start: Optional[str], end: Optional[str]) -> pd.DataFrame:
    if start:
        start_ts = pd.to_datetime(start)
        if start_ts.tzinfo is None:
            start_ts = start_ts.tz_localize("UTC")
        else:
            start_ts = start_ts.tz_convert("UTC")
        df = df[df.index >= start_ts]
    if end:
        end_ts = pd.to_datetime(end)
        if end_ts.tzinfo is None:
            end_ts = end_ts.tz_localize("UTC")
        else:
            end_ts = end_ts.tz_convert("UTC")
        df = df[df.index <= end_ts]
    return df


@dataclass(slots=True)
class MarketDataFetcher:
    """Wrapper around yfinance intraday/historical download with local caching."""

    ticker: str

    def _load_from_cache(self, cache_path: Path) -> Optional[pd.DataFrame]:
        if not cache_path.exists():
            return None
        age = time.time() - cache_path.stat().st_mtime
        if age <= _CACHE_MAX_AGE:
            cached = _read_cache(cache_path)
            if cached is not None:
                logger.info("Cache hit for %s (%s)", self.ticker, cache_path.name)
                return cached
        return None

    def get_prices(
        self,
        interval: Interval = "5m",
        period: str = "5d",
        start: Optional[str] = None,
        end: Optional[str] = None,
    ) -> pd.DataFrame:
        cache_path = _cache_file(self.ticker, interval, None if start or end else period, start, end)
        strict_window = bool(start or end)
        cached = self._load_from_cache(cache_path)
        if cached is not None:
            df = cached
            source = "cache"
        else:
            df = None
            source = "download"

        if df is None:
            try:
                df = yf.download(
                    self.ticker,
                    interval=interval,
                    period=None if start or end else period,
                    start=start,
                    end=end,
                    auto_adjust=False,
                    progress=False,
                )
            except Exception as exc:
                logger.warning("yfinance download failed for %s (%s): %s", self.ticker, interval, exc)
                cached = _fallback_cache(cache_path, self.ticker, interval)
                if cached is not None and (not strict_window or _covers_window(cached, start, end)):
                    logger.info("Using cached data for %s after failure", self.ticker)
                    df = cached
                    source = "fallback_cache"
                else:
                    raise

        if df is None or df.empty:
            logger.warning("yfinance returned empty dataframe for %s. Trying cache.", self.ticker)
            cached = _fallback_cache(cache_path, self.ticker, interval)
            if cached is not None and (not strict_window or _covers_window(cached, start, end)):
                df = cached
                source = "fallback_cache"
            else:
                raise ValueError(f"yfinance returned empty dataframe for {self.ticker}")

        if isinstance(df.columns, pd.MultiIndex):
            level_names = df.columns.names or []
            if "Ticker" in level_names:
                try:
                    df = df.xs(self.ticker, axis=1, level="Ticker")
                except (KeyError, ValueError):
                    df = df.droplevel(level_names.index("Ticker"), axis=1)
            else:
                df = df.droplevel(-1, axis=1)
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)

        index = pd.to_datetime(df.index)
        if index.tz is None:
            index = index.tz_localize("UTC", ambiguous="NaT", nonexistent="NaT")
        else:
            index = index.tz_convert("UTC")
        df.index = index
        df = df.dropna(how="any")
        df = df.rename(
            columns={
                "Open": "open",
                "High": "high",
                "Low": "low",
                "Close": "close",
                "Adj Close": "adj_close",
                "Volume": "volume",
            }
        )
        if strict_window and not _covers_window(df, start, end):
            cached = _fallback_cache(cache_path, self.ticker, interval)
            if cached is not None and _covers_window(cached, start, end):
                logger.info("Using cached data for %s to satisfy strict window %s -> %s", self.ticker, start, end)
                df = cached
                source = "fallback_cache"
            else:
                raise ValueError(f"Cached/downloaded data for {self.ticker} does not fully cover requested window.")
        df = _filter_window(df, start, end)
        if df.empty:
            raise ValueError(f"No data available for {self.ticker} in requested window.")
        if source == "download":
            _save_cache(df, cache_path)
        return df

    def resample(self, df: pd.DataFrame, rule: str) -> pd.DataFrame:
        """
        Resample price data to a coarser timeframe.
        """
        ohlc_dict = {
            "open": "first",
            "high": "max",
            "low": "min",
            "close": "last",
            "adj_close": "last",
            "volume": "sum",
        }
        resampled = df.resample(rule, label="right", closed="right").agg(ohlc_dict).dropna()
        return resampled
