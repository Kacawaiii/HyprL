#!/bin/bash
# Run HyprL Crypto Signal Generator
# 24/7 - crypto markets never close

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$(dirname "$SCRIPT_DIR")")"
VENV="$PROJECT_DIR/.venv/bin/python3"
OUTPUT="$PROJECT_DIR/live/logs/crypto_signals.jsonl"

# Load environment (use .env.bridge which has APCA_* variables)
set -a
source "$PROJECT_DIR/.env.bridge" 2>/dev/null || true
set +a

cd "$PROJECT_DIR"

# Run crypto signals for BTC and ETH (main cryptos)
echo "[$(date -u '+%Y-%m-%d %H:%M:%S')] Running crypto signal scan..."

$VENV scripts/run_crypto_signals.py \
    --symbols BTC/USD ETH/USD \
    --timeframe 1Hour \
    --threshold-long 0.53 \
    --threshold-short 0.47 \
    --max-position-pct 0.25 \
    --base-dir "$PROJECT_DIR" || echo "[Crypto] No actionable signals"

echo "[$(date -u '+%Y-%m-%d %H:%M:%S')] Crypto scan complete"
