#!/usr/bin/env python3
"""Run Crypto Signal Generator.

Generates signals for BTC, ETH and other cryptocurrencies.
Can be run 24/7 as crypto markets never close.

Usage:
    python scripts/run_crypto_signals.py --symbols BTC/USD ETH/USD
    python scripts/run_crypto_signals.py --all
"""

import argparse
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from hyprl.crypto.trader import CryptoConfig, format_crypto_signal
from hyprl.crypto.signals import CryptoSignalGenerator, format_crypto_scan


def main():
    parser = argparse.ArgumentParser(description="Crypto Signal Generator")
    parser.add_argument(
        "--symbols",
        nargs="+",
        default=["BTC/USD", "ETH/USD"],
        help="Crypto symbols to analyze"
    )
    parser.add_argument("--all", action="store_true", help="Scan all supported cryptos")
    parser.add_argument("--timeframe", default="1Hour", help="Timeframe (1Min, 15Min, 1Hour)")
    parser.add_argument("--threshold-long", type=float, default=0.58, help="Long threshold")
    parser.add_argument("--threshold-short", type=float, default=0.42, help="Short threshold")
    parser.add_argument("--max-position-pct", type=float, default=0.10, help="Max position %")
    parser.add_argument("--json", action="store_true", help="Output JSON")
    parser.add_argument("--base-dir", default=".", help="Base directory")
    args = parser.parse_args()

    # All supported symbols
    all_symbols = [
        "BTC/USD", "ETH/USD", "LTC/USD", "LINK/USD",
        "UNI/USD", "AAVE/USD", "AVAX/USD", "SOL/USD"
    ]

    symbols = all_symbols if args.all else args.symbols

    config = CryptoConfig(
        symbols=symbols,
        timeframe=args.timeframe,
        threshold_long=args.threshold_long,
        threshold_short=args.threshold_short,
        max_position_pct=args.max_position_pct,
    )

    generator = CryptoSignalGenerator(config, base_dir=args.base_dir)
    signals = generator.scan_all()

    if args.json:
        import json
        output = [
            {
                "symbol": s.symbol,
                "direction": s.direction,
                "probability": s.probability,
                "confidence": s.confidence,
                "size_pct": s.size_pct,
                "entry_price": s.entry_price,
                "stop_loss": s.stop_loss,
                "take_profit": s.take_profit,
                "reason": s.reason,
                "timestamp": s.timestamp.isoformat(),
            }
            for s in signals
        ]
        print(json.dumps(output, indent=2))
    else:
        print(format_crypto_scan(signals))

    # Return non-zero if no actionable signals
    actionable = [s for s in signals if s.direction != "neutral"]
    return 0 if actionable else 1


if __name__ == "__main__":
    sys.exit(main())
