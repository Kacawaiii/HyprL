#!/usr/bin/env python3
"""Train XGBoost models for crypto trading using Alpaca data."""

from __future__ import annotations

import argparse
import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

FEATURE_COLUMNS: tuple[str, ...] = (
    "ret_1h",
    "ret_4h",
    "ret_12h",
    "ret_24h",
    "ret_72h",
    "volatility_12h",
    "volatility_24h",
    "volatility_72h",
    "rsi_6",
    "rsi_14",
    "rsi_21",
    "sma_ratio_12",
    "sma_ratio_24",
    "sma_ratio_72",
    "volume_ratio_12",
    "volume_ratio_24",
    "volume_zscore",
    "atr_14",
    "atr_14_norm",
    "high_low_range",
    "true_range",
    "hour_of_day",
    "day_of_week",
    "is_weekend",
    "is_asia_session",
    "is_europe_session",
    "is_us_session",
)

XGB_PARAMS: dict[str, Any] = {
    "n_estimators": 200,
    "max_depth": 4,
    "learning_rate": 0.05,
    "subsample": 0.8,
    "colsample_bytree": 0.8,
    "reg_lambda": 3.0,
    "reg_alpha": 0.5,
    "min_child_weight": 5,
    "random_state": 42,
    "eval_metric": "logloss",
}


def _resolve_timeframe(timeframe: str):
    from alpaca.data.timeframe import TimeFrame, TimeFrameUnit

    tf_map = {
        "1Min": TimeFrame(1, TimeFrameUnit.Minute),
        "5Min": TimeFrame(5, TimeFrameUnit.Minute),
        "15Min": TimeFrame(15, TimeFrameUnit.Minute),
        "1Hour": TimeFrame(1, TimeFrameUnit.Hour),
        "1Day": TimeFrame(1, TimeFrameUnit.Day),
    }
    return tf_map.get(timeframe, TimeFrame(1, TimeFrameUnit.Hour))


def fetch_crypto_data(symbol: str, days: int, timeframe: str) -> pd.DataFrame:
    try:
        from alpaca.data.historical import CryptoHistoricalDataClient
        from alpaca.data.requests import CryptoBarsRequest
    except ImportError as exc:
        raise SystemExit("alpaca-py is required for crypto training") from exc

    api_key = os.environ.get("APCA_API_KEY_ID")
    secret_key = os.environ.get("APCA_API_SECRET_KEY")
    if api_key and secret_key:
        client = CryptoHistoricalDataClient(api_key=api_key, secret_key=secret_key)
    else:
        client = CryptoHistoricalDataClient()

    end = datetime.now(timezone.utc)
    start = end - timedelta(days=days)

    request = CryptoBarsRequest(
        symbol_or_symbols=symbol,
        timeframe=_resolve_timeframe(timeframe),
        start=start,
        end=end,
    )

    bars = client.get_crypto_bars(request)
    bar_data = bars.data if hasattr(bars, "data") else bars

    if symbol not in bar_data:
        raise SystemExit(f"No data returned for {symbol}")

    data = [
        {
            "timestamp": bar.timestamp,
            "open": float(bar.open),
            "high": float(bar.high),
            "low": float(bar.low),
            "close": float(bar.close),
            "volume": float(bar.volume),
        }
        for bar in bar_data[symbol]
    ]

    df = pd.DataFrame(data)
    if df.empty:
        raise SystemExit(f"Empty dataset for {symbol}")

    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    df = df.sort_values("timestamp").drop_duplicates("timestamp")
    df = df.set_index("timestamp")
    return df


def compute_rsi(series: pd.Series, period: int) -> pd.Series:
    delta = series.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = (-delta.where(delta < 0, 0.0))
    avg_gain = gain.rolling(period).mean()
    avg_loss = loss.rolling(period).mean()
    rs = avg_gain / avg_loss.replace(0, 1e-10)
    return 100 - (100 / (1 + rs))


def compute_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    for h in (1, 4, 12, 24, 72):
        df[f"ret_{h}h"] = df["close"].pct_change(h)

    returns = df["close"].pct_change()
    for h in (12, 24, 72):
        df[f"volatility_{h}h"] = returns.rolling(h).std()

    for period in (6, 14, 21):
        df[f"rsi_{period}"] = compute_rsi(df["close"], period)

    for h in (12, 24, 72):
        sma = df["close"].rolling(h).mean()
        df[f"sma_ratio_{h}"] = df["close"] / sma.replace(0, np.nan)

    for h in (12, 24):
        vol_sma = df["volume"].rolling(h).mean()
        df[f"volume_ratio_{h}"] = df["volume"] / vol_sma.replace(0, np.nan)

    volume_mean = df["volume"].rolling(24).mean()
    volume_std = df["volume"].rolling(24).std()
    df["volume_zscore"] = (df["volume"] - volume_mean) / volume_std.replace(0, np.nan)

    high_low = df["high"] - df["low"]
    high_close = (df["high"] - df["close"].shift()).abs()
    low_close = (df["low"] - df["close"].shift()).abs()
    tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)

    df["true_range"] = tr
    df["atr_14"] = tr.rolling(14).mean()
    df["atr_14_norm"] = df["atr_14"] / df["close"].replace(0, np.nan)
    df["high_low_range"] = (df["high"] - df["low"]) / df["close"].replace(0, np.nan)

    df["hour_of_day"] = df.index.hour / 24.0
    df["day_of_week"] = df.index.dayofweek / 7.0
    df["is_weekend"] = (df.index.dayofweek >= 5).astype(float)

    df["is_asia_session"] = ((df.index.hour >= 0) & (df.index.hour < 8)).astype(float)
    df["is_europe_session"] = ((df.index.hour >= 8) & (df.index.hour < 16)).astype(float)
    df["is_us_session"] = ((df.index.hour >= 14) & (df.index.hour < 22)).astype(float)

    return df


def compute_target(df: pd.DataFrame, threshold_pct: float, horizon_hours: int) -> pd.Series:
    future_return = df["close"].shift(-horizon_hours) / df["close"] - 1.0
    return (future_return > (threshold_pct / 100.0)).astype(int)


def split_time(df: pd.DataFrame, test_frac: float) -> tuple[pd.DataFrame, pd.DataFrame]:
    split_idx = int(len(df) * (1 - test_frac))
    if split_idx <= 0 or split_idx >= len(df):
        raise ValueError("Invalid time split; adjust test fraction")
    return df.iloc[:split_idx], df.iloc[split_idx:]


def train_symbol(
    symbol: str,
    days: int,
    timeframe: str,
    threshold_pct: float,
    horizon_hours: int,
    test_frac: float,
    output_dir: Path,
) -> dict[str, Any]:
    df = fetch_crypto_data(symbol, days=days, timeframe=timeframe)
    df = compute_features(df)
    df["target"] = compute_target(df, threshold_pct=threshold_pct, horizon_hours=horizon_hours)

    required_cols = list(FEATURE_COLUMNS) + ["target"]
    df = df.dropna(subset=required_cols)

    if df.empty:
        raise SystemExit(f"No usable rows for {symbol} after feature/target generation")

    train_df, test_df = split_time(df, test_frac=test_frac)

    X_train = train_df[list(FEATURE_COLUMNS)].to_numpy()
    y_train = train_df["target"].to_numpy()
    X_test = test_df[list(FEATURE_COLUMNS)].to_numpy()
    y_test = test_df["target"].to_numpy()

    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s = scaler.transform(X_test)

    pos = float((y_train == 1).sum())
    neg = float((y_train == 0).sum())
    scale_pos_weight = neg / pos if pos > 0 else 1.0

    model = XGBClassifier(**XGB_PARAMS, scale_pos_weight=scale_pos_weight)
    model.fit(X_train_s, y_train)

    train_acc = float(model.score(X_train_s, y_train))
    test_acc = float(model.score(X_test_s, y_test))

    output_dir.mkdir(parents=True, exist_ok=True)
    clean_symbol = symbol.replace("/", "_").lower()
    artifact_path = output_dir / f"{clean_symbol}_xgb.joblib"

    bundle = {
        "model": model,
        "scaler": scaler,
        "feature_columns": list(FEATURE_COLUMNS),
        "train_accuracy": train_acc,
        "test_accuracy": test_acc,
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "symbol": symbol,
        "threshold_pct": threshold_pct,
        "horizon_hours": horizon_hours,
    }
    joblib.dump(bundle, artifact_path)

    return {
        "symbol": symbol,
        "artifact": str(artifact_path),
        "rows_total": int(len(df)),
        "rows_train": int(len(train_df)),
        "rows_test": int(len(test_df)),
        "pos_rate_train": float(y_train.mean()) if len(y_train) else 0.0,
        "pos_rate_test": float(y_test.mean()) if len(y_test) else 0.0,
        "train_accuracy": train_acc,
        "test_accuracy": test_acc,
        "trained_at": bundle["trained_at"],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Train crypto XGBoost models")
    parser.add_argument("--symbols", nargs="+", default=["BTC/USD", "ETH/USD"])
    parser.add_argument("--days", type=int, default=365)
    parser.add_argument("--timeframe", default="1Hour")
    parser.add_argument("--threshold-pct", type=float, default=0.5)
    parser.add_argument("--horizon-hours", type=int, default=4)
    parser.add_argument("--test-frac", type=float, default=0.2)
    parser.add_argument("--output-dir", default="models/crypto")
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    reports = []

    for symbol in args.symbols:
        report = train_symbol(
            symbol=symbol,
            days=args.days,
            timeframe=args.timeframe,
            threshold_pct=args.threshold_pct,
            horizon_hours=args.horizon_hours,
            test_frac=args.test_frac,
            output_dir=output_dir,
        )
        reports.append(report)
        print(
            f"[TRAIN] {symbol} rows={report['rows_total']} "
            f"train={report['rows_train']} test={report['rows_test']} "
            f"acc_train={report['train_accuracy']:.3f} acc_test={report['test_accuracy']:.3f}"
        )
        print(f"[OUT] {symbol} artifact={report['artifact']}")

    report_payload = {
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "threshold_pct": args.threshold_pct,
        "horizon_hours": args.horizon_hours,
        "timeframe": args.timeframe,
        "days": args.days,
        "features": list(FEATURE_COLUMNS),
        "reports": reports,
    }

    report_path = output_dir / "training_report.json"
    report_path.write_text(json.dumps(report_payload, indent=2))
    print(f"[REPORT] {report_path}")


if __name__ == "__main__":
    main()
