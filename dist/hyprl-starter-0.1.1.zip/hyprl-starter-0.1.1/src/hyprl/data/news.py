from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

import yfinance as yf


@dataclass(slots=True)
class NewsArticle:
    title: str
    publisher: str
    link: str
    sentiment: Optional[float] = None


@dataclass(slots=True)
class NewsFetcher:
    ticker: str

    def fetch_latest(self, limit: int = 10) -> List[NewsArticle]:
        ticker = yf.Ticker(self.ticker)
        raw_news = ticker.news or []
        articles: List[NewsArticle] = []
        for payload in raw_news[:limit]:
            article = NewsArticle(
                title=payload.get("title", ""),
                publisher=payload.get("publisher", ""),
                link=payload.get("link", ""),
            )
            articles.append(article)
        return articles
