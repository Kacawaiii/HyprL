"""Metrics utilities for HyprL."""
