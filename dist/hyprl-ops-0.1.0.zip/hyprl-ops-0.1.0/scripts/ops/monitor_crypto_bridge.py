#!/usr/bin/env python3
"""Monitor crypto bridge order logs and send alerts to Discord."""

from __future__ import annotations

import argparse
import json
import os
import time
import urllib.request
from pathlib import Path
from typing import Iterable

DEFAULT_ALERT_EVENTS = {
    "order_failed",
    "close_failed",
    "flip_close_failed",
    "crypto_allocation_blocked",
    "crypto_allocation_missing_broker",
    "crypto_allocation_missing_equity",
    "crypto_allocation_check_failed",
    "crypto_allocation_missing_notional",
    "crypto_allocation_missing_price",
    "crypto_allocation_qty_zero",
    "daily_dd_stop",
    "kill_switch_active",
    "kill_switch_symbol_active",
    "unknown_notional_block",
    "notional_unknown",
}


def load_offset(path: Path) -> int:
    if not path.exists():
        return 0
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return 0
    return int(payload.get("file_offset", 0) or 0)


def save_offset(path: Path, offset: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps({"file_offset": offset}, indent=2, sort_keys=True)
    path.write_text(payload, encoding="utf-8")


def send_discord(webhook: str, content: str) -> None:
    if not webhook:
        return
    body = json.dumps({"content": content}).encode("utf-8")
    req = urllib.request.Request(
        webhook,
        data=body,
        headers={
            "Content-Type": "application/json",
            "User-Agent": "HyprL-Monitor/1.0",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=5):
        pass


def format_event(event: dict) -> str:
    event_name = str(event.get("event", ""))
    symbol = str(event.get("symbol", ""))
    ts = str(event.get("ts", ""))
    error = str(event.get("error", ""))
    extra = ""
    if error:
        extra = f" | {error}"
    if symbol:
        return f"[crypto_bridge] {event_name} {symbol} @ {ts}{extra}".strip()
    return f"[crypto_bridge] {event_name} @ {ts}{extra}".strip()


def iter_new_lines(path: Path, offset: int) -> tuple[int, Iterable[str]]:
    if not path.exists():
        return offset, []
    size = path.stat().st_size
    if size < offset:
        offset = 0
    with path.open("r", encoding="utf-8") as handle:
        handle.seek(offset)
        lines = handle.readlines()
        offset = handle.tell()
    return offset, lines


def process_lines(lines: Iterable[str], alert_events: set[str], webhook: str) -> int:
    sent = 0
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        event_name = str(event.get("event", ""))
        if event_name not in alert_events:
            continue
        message = format_event(event)
        try:
            send_discord(webhook, message)
            sent += 1
        except Exception:
            continue
    return sent


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Monitor crypto bridge orders log.")
    parser.add_argument(
        "--orders-log",
        default="live/execution/crypto/orders.jsonl",
        help="Path to crypto orders JSONL.",
    )
    parser.add_argument(
        "--state",
        default="live/execution/crypto/monitor_state.json",
        help="Offset state file.",
    )
    parser.add_argument(
        "--webhook",
        default="",
        help="Discord webhook URL (defaults to DISCORD_WEBHOOK_URL).",
    )
    parser.add_argument(
        "--alert-events",
        default=",".join(sorted(DEFAULT_ALERT_EVENTS)),
        help="Comma-separated events to alert on.",
    )
    parser.add_argument("--poll-seconds", type=float, default=10.0)
    parser.add_argument("--once", action="store_true", help="Process once and exit.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    webhook = args.webhook or os.environ.get("DISCORD_WEBHOOK_URL", "")
    alert_events = {e.strip() for e in args.alert_events.split(",") if e.strip()}
    if not alert_events:
        alert_events = set(DEFAULT_ALERT_EVENTS)

    orders_log = Path(args.orders_log)
    state_path = Path(args.state)
    offset = load_offset(state_path)

    while True:
        offset, lines = iter_new_lines(orders_log, offset)
        process_lines(lines, alert_events, webhook)
        save_offset(state_path, offset)
        if args.once:
            break
        time.sleep(args.poll_seconds)


if __name__ == "__main__":
    main()
