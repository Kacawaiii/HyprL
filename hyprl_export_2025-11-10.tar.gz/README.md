# HyprL – V1 Signal & Backtest Engine

HyprL is a research-grade trading analysis engine that ingests OHLCV (and sentiment stubs), builds multi-timeframe indicators, trains a probabilistic model (logistic regression), and simulates trades with realistic ATR-based risk, commissions, slippage, and buy‑and‑hold benchmarks. V1 is a clean reference implementation for quant experimentation—not a production trading bot.

## Project Layout
- `src/hyprl/data/` – `MarketDataFetcher` (yfinance download, cache, timezone fixes, column flattening).
- `src/hyprl/indicators/` – enriched technical feature frame (SMA/EMA ratios, RSI, ATR, volatility, rolling returns).
- `src/hyprl/model/` – logistic regression probability model with StandardScaler + deterministic random_state.
- `src/hyprl/risk/` – ATR-based `RiskConfig` and `plan_trade` sizing (stops, take-profit, risk_pct).
- `src/hyprl/pipeline.py` – single-run `AnalysisPipeline` combining indicators, sentiment stub, model, risk plan.
- `src/hyprl/backtest/` – walk-forward engine with thresholds, EV filter, trade logging, costs, benchmark.
- `scripts/` – CLI utilities (analysis, backtest, threshold sweep, universe sweep, trade analysis).
- `configs/` – optional per-ticker YAML overrides (e.g., threshold baselines).

## Installation
```bash
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -e .
pip install pytest
```
Optional accelerator (Rust + maturin):
```bash
pip install maturin
cd accelerators/rust/hyprl_accel
maturin develop --release
```

## Quickstart
```bash
# 1) Single analysis
python scripts/run_analysis.py --ticker AAPL --period 5d

# 2) Backtest with costs + benchmark + optional CSV
python scripts/run_backtest.py \
  --ticker AAPL \
  --period 1y \
  --initial-balance 10000 \
  --seed 42 \
  --long-threshold 0.60 \
  --short-threshold 0.40 \
  --export-trades data/trades_AAPL_1y.csv

# 3) Threshold sweep (long threshold grid, short threshold from config)
python scripts/run_threshold_sweep.py \
  --ticker AAPL \
  --period 1y \
  --initial-balance 10000 \
  --seed 42

# 4) Universe sweep (multiple tickers, CSV summary)
python scripts/run_universe_sweep.py \
  --tickers AAPL,MSFT,NVDA,TSLA \
  --period 1y \
  --initial-balance 10000 \
  --seed 42 \
  --output data/universe_1y.csv

# 5) Supersearch (research-only grid search)
python scripts/run_supersearch.py \
  --ticker AAPL \
  --period 1y \
  --interval 1h \
  --initial-balance 10000 \
  --seed 42 \
  --long-thresholds "0.50,0.55,0.60" \
  --short-thresholds "0.35,0.40" \
  --risk-pcts "0.010,0.015,0.020" \
  --output data/supersearch_AAPL_1y.csv

# 6) Trade analysis (after exporting trades)
python scripts/analyze_trades.py --trades data/trades_AAPL_1y.csv

# Optional: alternative model + probability calibration
python scripts/run_backtest.py \
  --ticker NVDA \
  --period 1y \
  --initial-balance 10000 \
  --seed 42 \
  --long-threshold 0.55 \
  --short-threshold 0.40 \
  --model-type random_forest \
  --calibration platt

# 7) GUI (optional, Streamlit)
pip install streamlit
streamlit run scripts/hyprl_gui.py

# 8) Market Replay GUI
streamlit run scripts/hyprl_replay_gui.py
``` 
Replay app:
- Mode simulation (HyprL engine, risk profiles Safe/Normal/Aggressive, metrics + trades preview, snapshot export).
- Mode replay CSV (charger un trades.csv existant, reconstruire equity, slider temporel, snapshot).

# 9) Model Comparison (NVDA example)
```bash
python scripts/compare_models.py --ticker NVDA --period 1y --interval 1h --risk-profile normal --output data/nvda_model_compare.csv
```

## Adaptive Mode (v1.2)
HyprL can shift risk settings, thresholds, and even model calibration based on recent performance. Define regimes inside a ticker preset:

```yaml
adaptive:
  enabled: true
  lookback_trades: 25
  default_regime: normal
  regimes:
    safe:
      min_equity_drawdown: 0.08
      max_equity_drawdown: 1.0
      risk_overrides:
        risk_pct: 0.01
        reward_multiple: 1.5
      threshold_overrides:
        long_shift: 0.02
        short_shift: -0.02
    normal:
      min_equity_drawdown: -0.01
      max_equity_drawdown: 0.08
    aggressive:
      min_equity_drawdown: -0.05
      max_equity_drawdown: -0.01
      risk_overrides:
        risk_pct: 0.025
      threshold_overrides:
        long_shift: -0.02
        short_shift: 0.02
```

Enable it from the CLI or GUI:

```bash
python scripts/run_backtest.py \
  --ticker AAPL \
  --period 1y \
  --initial-balance 10000 \
  --seed 42 \
  --adaptive \
  --adaptive-lookback 30
```

Results now include the final regime, number of regime switches, and per-regime usage summaries. Streamlit GUIs expose the same toggle plus lookback sliders.

## Reference Presets (v1.2)
- **AAPL 1h (tradable)** – logistic + platt, `short=0.40`, `long=0.52`, normal risk (risk_pct 1.5%, RR 2.0), EV≥20% risk, rolling-return trend filter. Non-adaptive baseline (seed 42, 1y@1h) → strat ≈1.9%, bench ≈18.0%, alpha ≈-16.1 pts, PF≈1.02, Sharpe≈0.19, max DD≈17.9%, 58 trades. Adaptive mode is opt-in (`--adaptive`) and yields ≈5.9% strat, PF≈1.17, Sharpe≈0.47, DD≈13.6% (29 trades, normal→safe once).
- **MSFT 1h (research-only)** – logistic + platt baseline (seed 42, 1y@1h) loses: strat ≈-5.8%, bench ≈17.2%, alpha ≈-22.9 pts, PF≈0.95, Sharpe≈-0.94, DD≈9.1%, 21 trades.
- **NVDA 1h (calibration-only)** – logistic + platt baseline (seed 42, 1y@1h) sits at strat ≈-1.5%, bench ≈28.0%, alpha ≈-29.5 pts, PF≈0.98, Sharpe≈-0.01, DD≈14.7%, 78 trades; aggressive threshold (0.65) produces ≈0.37% but only 2 trades, so keep for calibration.

Universe v1.2 (non-adaptive, 1y@1h, seed 42) summary:

<!-- BEGIN_UNIVERSE_V1_2 -->
Ticker | Tradable | Short | Best Long | Strat % | Ann % | Bench % | Alpha % | PF | Sharpe | Max DD % | Trades | Win % | Exp | Score | Best Regime
--- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | ---
AAPL | YES | 0.40 | 0.52 | 1.89 | 1.89 | 17.99 | -16.10 | 1.02 | 0.19 | 17.87 | 58 | 43.10 | 3.26 | -0.09 | normal
MSFT | NO | 0.40 | 0.75 | -5.78 | -5.78 | 17.16 | -22.94 | 0.95 | -0.94 | 9.05 | 21 | 28.57 | -27.53 | -1.52 | normal
NVDA | NO | 0.40 | 0.65 | 0.37 | 0.37 | 27.97 | -27.60 | 1.22 | 0.11 | 1.68 | 2 | 50.00 | 18.64 | -0.00 | normal
<!-- END_UNIVERSE_V1_2 -->
```

## Current V1 Results (examples)
- **NVDA** (1y, 1h bars, long_th=0.55, short_th=0.40, seed=42):
  - Strategy return ≈ +19.9% vs buy & hold ≈ +28.0%.
  - Sharpe ≈ 1.53, max drawdown ≈ 6.4%, ~45% win rate, positive expectancy with EV filter.
- **AAPL** (1y, 1h, same thresholds): strategy slightly underperforms benchmark (~15% vs ~18%) but delivers Sharpe ~1.15 with realistic costs.
- Similar behavior on MSFT/TSLA (strategy near but below benchmark on strong uptrends). Treat V1 as a research tool to study driver metrics and alpha gaps.

## Limitations & Next Steps
- Single logistic regression baseline (no calibration, no ensemble).
- Backtest handles one instrument at a time (no portfolio interactions yet).
- No live order execution; EV filter is a heuristic gate.
- Use V1 for diagnostics, sweeps, and trade logging; future work should explore probability calibration, richer models (XGBoost/NN), and smarter risk/portfolio overlays.
