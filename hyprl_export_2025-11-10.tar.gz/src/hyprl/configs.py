from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from hyprl.adaptive.engine import AdaptiveConfig, AdaptiveRegime

try:
    import yaml
except ImportError:  # pragma: no cover - optional dependency
    yaml = None

CONFIG_ROOT = Path(__file__).resolve().parents[2] / "configs"


def _normalize_tokens(ticker: str, interval: str) -> tuple[str, str]:
    return ticker.upper(), interval.lower()


def _read_yaml(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        raw = handle.read()
    if yaml is not None:
        data = yaml.safe_load(raw) or {}
    else:
        data = _parse_minimal_yaml(raw)
    if not isinstance(data, dict):
        raise ValueError(f"Config file {path} must contain a mapping.")
    return data


def _parse_minimal_yaml(text: str) -> dict[str, Any]:
    lines = text.splitlines()

    def _parse_block(start_index: int, indent: int) -> tuple[dict[str, Any], int]:
        mapping: dict[str, Any] = {}
        index = start_index
        while index < len(lines):
            raw_line = lines[index]
            if not raw_line.strip() or raw_line.lstrip().startswith("#"):
                index += 1
                continue
            current_indent = len(raw_line) - len(raw_line.lstrip(" "))
            if current_indent < indent:
                break
            if ":" not in raw_line:
                raise ValueError(f"Unsupported config line: {raw_line!r}")
            key, value = raw_line.split(":", 1)
            key = key.strip()
            value = value.strip()
            if not key:
                raise ValueError(f"Invalid key in line: {raw_line!r}")
            if value:
                mapping[key] = _coerce_scalar(value.strip("'\""))
                index += 1
            else:
                child, next_index = _parse_block(index + 1, current_indent + 2)
                mapping[key] = child
                index = next_index
        return mapping, index

    result, _ = _parse_block(0, 0)
    return result


def _coerce_scalar(value: str) -> Any:
    if value == "":
        return ""
    lowered = value.lower()
    if lowered in {"true", "false"}:
        return lowered == "true"
    try:
        return float(value)
    except ValueError:
        return value


def load_ticker_settings(ticker: str, interval: str) -> dict[str, Any]:
    norm_ticker, norm_interval = _normalize_tokens(ticker, interval)
    config_path = CONFIG_ROOT / f"{norm_ticker}-{norm_interval}.yaml"
    if not config_path.exists():
        return {}
    return _read_yaml(config_path)


def load_threshold(ticker: str, interval: str, default: float = 0.4) -> float:
    """
    Load a ticker/interval-specific decision threshold from YAML.

    Parameters
    ----------
    ticker:
        Instrument ticker symbol.
    interval:
        Data interval string (e.g., '1h').
    default:
        Fallback threshold when no config is present.
    """

    data = load_ticker_settings(ticker, interval)
    if not data:
        return default
    threshold = data.get("threshold", default)
    try:
        return float(threshold)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid threshold value in {config_path}: {threshold}") from exc


def get_risk_settings(settings: dict[str, Any], profile: Optional[str] = None) -> dict[str, Any]:
    base = dict(settings.get("risk", {}))
    profiles = settings.get("risk_profiles") or {}
    selected = profile or settings.get("default_risk_profile")
    if selected and selected in profiles:
        profile_data = profiles[selected]
        if isinstance(profile_data, dict):
            base.update(profile_data)
    return {
        "risk_pct": float(base.get("risk_pct", 0.02)),
        "atr_multiplier": float(base.get("atr_multiplier", 1.0)),
        "reward_multiple": float(base.get("reward_multiple", 1.5)),
        "min_position_size": int(base.get("min_position_size", 1)),
    }


def _build_regimes(raw: Any) -> dict[str, AdaptiveRegime]:
    if not isinstance(raw, dict):
        return {}
    regimes: dict[str, AdaptiveRegime] = {}

    def _coerce_mapping(obj: Any) -> dict[str, Any]:
        if isinstance(obj, dict):
            return dict(obj)
        if isinstance(obj, str):
            text = obj.strip()
            if not text or text == "{}":
                return {}
            try:
                parsed = json.loads(text)
            except json.JSONDecodeError:
                return {}
            if isinstance(parsed, dict):
                return parsed
        return {}

    for name, cfg in raw.items():
        if not isinstance(cfg, dict):
            continue
        risk_map = _coerce_mapping(cfg.get("risk_overrides"))
        threshold_map = _coerce_mapping(cfg.get("threshold_overrides"))
        model_map = _coerce_mapping(cfg.get("model_overrides"))
        regimes[name] = AdaptiveRegime(
            name=name,
            min_equity_drawdown=float(cfg.get("min_equity_drawdown", 0.0)),
            max_equity_drawdown=float(cfg.get("max_equity_drawdown", 1.0)),
            min_profit_factor=float(cfg.get("min_profit_factor", 0.0)),
            min_sharpe=float(cfg.get("min_sharpe", float("-inf"))),
            min_expectancy=float(cfg.get("min_expectancy", float("-inf"))),
            risk_overrides={str(k): float(v) for k, v in risk_map.items()},
            threshold_overrides={str(k): float(v) for k, v in threshold_map.items()},
            model_overrides={str(k): str(v) for k, v in model_map.items()},
        )
    return regimes


def get_adaptive_config(settings: dict[str, Any], overrides: Optional[dict[str, Any]] = None) -> AdaptiveConfig:
    base = dict(settings.get("adaptive", {}))
    data = dict(base)
    if overrides:
        data.update(overrides)
    enable_flag = data.get("enable", data.get("enabled", False))
    lookback = int(data.get("lookback_trades", data.get("window_trades", 20)))
    default_regime = str(data.get("default_regime", data.get("normal_profile", "normal")))
    regimes = _build_regimes(data.get("regimes"))
    return AdaptiveConfig(
        enable=bool(enable_flag),
        lookback_trades=lookback,
        default_regime=default_regime,
        regimes=regimes,
    )
