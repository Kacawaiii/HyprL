from __future__ import annotations

from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Iterable, Optional

import math
import pandas as pd

from hyprl.adaptive.engine import AdaptiveConfig
from hyprl.backtest.runner import BacktestConfig, run_backtest
from hyprl.configs import get_risk_settings, load_ticker_settings
from hyprl.risk.manager import RiskConfig


@dataclass(slots=True)
class SearchConfig:
    ticker: str
    period: Optional[str] = None
    start: Optional[str] = None
    end: Optional[str] = None
    interval: str = "1h"
    initial_balance: float = 10_000.0
    seed: int = 42
    use_presets: bool = True
    long_thresholds: list[float] = field(default_factory=list)
    short_thresholds: list[float] = field(default_factory=list)
    risk_pcts: list[float] = field(default_factory=list)
    min_ev_multiples: Optional[list[float]] = None
    trend_filter_flags: Optional[list[bool]] = None

    def validate(self) -> None:
        if not self.period and not (self.start and self.end):
            raise ValueError("SearchConfig requires --period or both --start and --end.")


@dataclass(slots=True)
class CandidateConfig:
    long_threshold: float
    short_threshold: float
    risk_pct: float
    min_ev_multiple: float
    trend_filter: bool


@dataclass(slots=True)
class SearchResult:
    config: CandidateConfig
    strategy_return_pct: float
    benchmark_return_pct: float
    alpha_pct: float
    profit_factor: float
    sharpe: Optional[float]
    max_drawdown_pct: float
    expectancy: float
    n_trades: int
    win_rate_pct: float


def _resolve_list(values: list[float], fallback: float) -> list[float]:
    target = [float(v) for v in values if math.isfinite(float(v))] if values else []
    if not target:
        target = [float(fallback)]
    return target


def _resolve_bool_list(values: Optional[list[bool]], fallback: bool) -> list[bool]:
    if values is None or not values:
        return [bool(fallback)]
    return [bool(v) for v in values]


def _score_tuple(result: SearchResult) -> tuple[float, float, float]:
    pf = result.profit_factor if math.isfinite(result.profit_factor) else 0.0
    sharpe = result.sharpe if (result.sharpe is not None and math.isfinite(result.sharpe)) else float("-inf")
    max_dd = result.max_drawdown_pct if math.isfinite(result.max_drawdown_pct) else float("inf")
    return (-pf, -sharpe, max_dd)


def run_search(search_cfg: SearchConfig) -> list[SearchResult]:
    search_cfg.validate()
    settings = load_ticker_settings(search_cfg.ticker, search_cfg.interval) if search_cfg.use_presets else {}
    base_long = float(settings.get("long_threshold", 0.6))
    base_short = float(settings.get("short_threshold", 0.4))
    risk_profile = settings.get("default_risk_profile") if search_cfg.use_presets else None
    risk_params = get_risk_settings(settings, profile=risk_profile)
    base_risk = RiskConfig(
        balance=search_cfg.initial_balance,
        risk_pct=float(risk_params["risk_pct"]),
        atr_multiplier=float(risk_params["atr_multiplier"]),
        reward_multiple=float(risk_params["reward_multiple"]),
        min_position_size=int(risk_params["min_position_size"]),
    )
    min_ev_default = float(settings.get("min_ev_multiple", 0.0)) if search_cfg.use_presets else 0.0
    trend_default = bool(settings.get("enable_trend_filter", False)) if search_cfg.use_presets else False
    trend_long_min = float(settings.get("trend_long_min", 0.0)) if search_cfg.use_presets else 0.0
    trend_short_min = float(settings.get("trend_short_min", 0.0)) if search_cfg.use_presets else 0.0
    model_type = str(settings.get("model_type", "logistic")) if search_cfg.use_presets else "logistic"
    calibration = str(settings.get("calibration", "none")) if search_cfg.use_presets else "none"

    long_values = _resolve_list(search_cfg.long_thresholds, base_long)
    short_values = _resolve_list(search_cfg.short_thresholds, base_short)
    risk_values = _resolve_list(search_cfg.risk_pcts, base_risk.risk_pct)
    min_ev_values = (
        _resolve_list(search_cfg.min_ev_multiples or [], min_ev_default)
        if search_cfg.min_ev_multiples is not None
        else [min_ev_default]
    )
    trend_values = _resolve_bool_list(search_cfg.trend_filter_flags, trend_default)

    adaptive_cfg = AdaptiveConfig(enable=False, lookback_trades=20, default_regime="normal", regimes={})
    results: list[SearchResult] = []

    for long_threshold in long_values:
        for short_threshold in short_values:
            if not (0.0 < short_threshold <= long_threshold < 1.0):
                continue
            for risk_pct in risk_values:
                if risk_pct <= 0:
                    continue
                risk_template = replace(base_risk, risk_pct=float(risk_pct))
                for min_ev_multiple in min_ev_values:
                    if min_ev_multiple < 0:
                        continue
                    for trend_flag in trend_values:
                        candidate = CandidateConfig(
                            long_threshold=float(long_threshold),
                            short_threshold=float(short_threshold),
                            risk_pct=float(risk_pct),
                            min_ev_multiple=float(min_ev_multiple),
                            trend_filter=bool(trend_flag),
                        )
                        bt_config = BacktestConfig(
                            ticker=search_cfg.ticker,
                            period=search_cfg.period,
                            start=search_cfg.start,
                            end=search_cfg.end,
                            interval=search_cfg.interval,
                            initial_balance=search_cfg.initial_balance,
                            long_threshold=candidate.long_threshold,
                            short_threshold=candidate.short_threshold,
                            model_type=model_type,
                            calibration=calibration,
                            risk=risk_template,
                            risk_profile="",
                            risk_profiles={},
                            adaptive=adaptive_cfg,
                            random_state=search_cfg.seed,
                            min_ev_multiple=candidate.min_ev_multiple,
                            enable_trend_filter=candidate.trend_filter,
                            trend_long_min=trend_long_min,
                            trend_short_min=trend_short_min,
                        )
                        try:
                            result = run_backtest(bt_config)
                        except Exception:
                            continue
                        strategy_return_pct = (
                            (result.final_balance / search_cfg.initial_balance - 1.0) * 100.0
                            if search_cfg.initial_balance > 0
                            else 0.0
                        )
                        benchmark_return_pct = float(result.benchmark_return)
                        alpha_pct = strategy_return_pct - benchmark_return_pct
                        profit_factor = float(result.profit_factor or 0.0)
                        sharpe = result.sharpe_ratio
                        max_drawdown_pct = float(result.max_drawdown * 100.0)
                        expectancy = float(result.expectancy)
                        win_rate_pct = float(result.win_rate * 100.0)
                        row = SearchResult(
                            config=candidate,
                            strategy_return_pct=strategy_return_pct,
                            benchmark_return_pct=benchmark_return_pct,
                            alpha_pct=alpha_pct,
                            profit_factor=profit_factor,
                            sharpe=sharpe,
                            max_drawdown_pct=max_drawdown_pct,
                            expectancy=expectancy,
                            n_trades=result.n_trades,
                            win_rate_pct=win_rate_pct,
                        )
                        results.append(row)

    results.sort(key=_score_tuple)
    return results


def save_results_csv(results: Iterable[SearchResult], path: Path) -> None:
    rows = []
    for res in results:
        rows.append(
            {
                "long_threshold": res.config.long_threshold,
                "short_threshold": res.config.short_threshold,
                "risk_pct": res.config.risk_pct,
                "min_ev_multiple": res.config.min_ev_multiple,
                "trend_filter": res.config.trend_filter,
                "strategy_return_pct": res.strategy_return_pct,
                "benchmark_return_pct": res.benchmark_return_pct,
                "alpha_pct": res.alpha_pct,
                "profit_factor": res.profit_factor,
                "sharpe": res.sharpe,
                "max_drawdown_pct": res.max_drawdown_pct,
                "expectancy": res.expectancy,
                "n_trades": res.n_trades,
                "win_rate_pct": res.win_rate_pct,
            }
        )
    df = pd.DataFrame.from_records(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
