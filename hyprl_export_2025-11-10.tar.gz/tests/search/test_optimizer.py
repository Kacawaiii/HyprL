from __future__ import annotations

from pathlib import Path
from typing import Callable

import math
import pandas as pd
import pytest
import numpy as np

from hyprl.backtest import runner as backtest_runner
from hyprl.search.optimizer import SearchConfig, run_search, save_results_csv


@pytest.fixture(autouse=True)
def stub_prices(monkeypatch: pytest.MonkeyPatch) -> None:
    periods = 320
    index = pd.date_range("2024-01-01", periods=periods, freq="h")
    base = pd.Series(np.sin(np.linspace(0.0, 12.0, periods)), index=index)
    trend = 100.0 + pd.Series(np.linspace(0.0, 2.0, periods), index=index)
    price = trend + base
    prices = pd.DataFrame(
        {
            "open": price + 0.05,
            "high": price + 0.75,
            "low": price - 0.75,
            "close": price + 0.2,
            "volume": 1_000_000.0,
        },
        index=index,
    )

    def _fake_get_prices(self, interval, period, start, end):  # noqa: ANN001
        return prices

    monkeypatch.setattr(backtest_runner.MarketDataFetcher, "get_prices", _fake_get_prices)


def test_run_search_sorts_by_profit_factor(tmp_path: Path) -> None:
    config = SearchConfig(
        ticker="TEST",
        period="90d",
        interval="1h",
        initial_balance=50_000.0,
        seed=7,
        use_presets=False,
        long_thresholds=[0.55, 0.6],
        short_thresholds=[0.35, 0.4],
        risk_pcts=[0.01, 0.015],
        min_ev_multiples=[0.0, 0.1],
        trend_filter_flags=[False, True],
    )
    results = run_search(config)
    assert results, "expected at least one search result"
    sort_key: Callable = lambda res: (
        -float(res.profit_factor),
        -float(res.sharpe or float("-inf")),
        float(res.max_drawdown_pct),
    )
    assert results == sorted(results, key=sort_key)
    for res in results:
        assert math.isfinite(res.strategy_return_pct)
        assert math.isfinite(res.alpha_pct)
        assert math.isfinite(res.max_drawdown_pct)
        assert res.n_trades >= 0
        assert 0.0 <= res.config.short_threshold <= res.config.long_threshold <= 1.0

    out_path = tmp_path / "search.csv"
    save_results_csv(results, out_path)
    df = pd.read_csv(out_path)
    assert len(df) == len(results)
    assert set(["long_threshold", "short_threshold", "risk_pct"]).issubset(df.columns)
