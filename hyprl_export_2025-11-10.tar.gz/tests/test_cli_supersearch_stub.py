from __future__ import annotations

import json
import runpy
import sys
from pathlib import Path
import sys


def test_supersearch_cli_writes_artifacts(tmp_path: Path, monkeypatch) -> None:
    repo_root = Path(__file__).resolve().parents[1]
    script = repo_root / "scripts" / "run_supersearch.py"
    outdir = tmp_path / "reports"
    cfg = tmp_path / "dummy.yaml"
    cfg.write_text("timeframe: '1h'\n", encoding="utf-8")

    monkeypatch.syspath_prepend(str(repo_root))

    argv = [
        "run_supersearch.py",
        "--config",
        str(cfg),
        "--tickers",
        "AAPL,MSFT,NVDA",
        "--timeframe",
        "1h",
        "--regimes",
        "on",
        "--constraints",
        "maxdd<=0.15,cvar95<=0.08,dsr>0,pboc<=0.10",
        "--out",
        str(outdir),
    ]
    monkeypatch.setattr(sys, "argv", argv)

    runpy.run_path(str(script), run_name="__main__")

    lb = outdir / "leaderboard.csv"
    gr = outdir / "gate_report.json"
    assert lb.exists()
    assert gr.exists()

    data = json.loads(gr.read_text(encoding="utf-8"))
    assert "cfg_001" in data
    assert "gate" in data["cfg_001"]
