from __future__ import annotations

import pandas as pd
import pytest

from hyprl.data import market


@pytest.fixture(autouse=True)
def _isolate_price_cache(monkeypatch, tmp_path):
    cache_root = tmp_path / "price-cache"
    monkeypatch.setattr(market, "_CACHE_ROOT", cache_root)
    cache_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(market, "_CACHE_MAX_AGE", 0)


def _single_level_df(index: pd.DatetimeIndex) -> pd.DataFrame:
    data = {
        "Open": [1.0, 2.0],
        "High": [1.5, 2.5],
        "Low": [0.5, 1.5],
        "Close": [1.2, 2.2],
        "Adj Close": [1.1, 2.1],
        "Volume": [100, 200],
    }
    return pd.DataFrame(data, index=index)


def test_get_prices_selects_multiindex_ticker_level(monkeypatch):
    index = pd.date_range("2024-01-01", periods=2, freq="D", tz="UTC")
    fields = ["Open", "High", "Low", "Close", "Adj Close", "Volume"]
    data: dict[tuple[str, str], list[float]] = {}
    for offset, field in enumerate(fields):
        base = float(offset + 1)
        data[(field, "AAPL")] = [base, base + 0.5]
        data[(field, "MSFT")] = [(base + 10), (base + 10.5)]
    columns = pd.MultiIndex.from_tuples(list(data.keys()), names=["Field", "Ticker"])
    df = pd.DataFrame(data, index=index)
    df.columns = columns
    monkeypatch.setattr(market.yf, "download", lambda *args, **kwargs: df.copy())

    fetcher = market.MarketDataFetcher("AAPL")
    result = fetcher.get_prices()

    assert list(result.columns) == ["open", "high", "low", "close", "adj_close", "volume"]
    assert pytest.approx(result.iloc[0]["open"], rel=1e-9) == 1.0
    assert pytest.approx(result.iloc[0]["volume"], rel=1e-9) == 6.0


def test_get_prices_droplevel_without_ticker(monkeypatch):
    index = pd.date_range("2024-02-01", periods=2, freq="D", tz="UTC")
    base_df = _single_level_df(index)
    columns = pd.MultiIndex.from_arrays(
        [list(base_df.columns), ["noop"] * len(base_df.columns)],
        names=["Metric", None],
    )
    df = pd.DataFrame(base_df.to_numpy(), index=index, columns=columns)
    monkeypatch.setattr(market.yf, "download", lambda *args, **kwargs: df.copy())

    result = market.MarketDataFetcher("AAPL").get_prices()

    assert list(result.columns) == ["open", "high", "low", "close", "adj_close", "volume"]
    assert result.equals(
        pd.DataFrame(
            {
                "open": [1.0, 2.0],
                "high": [1.5, 2.5],
                "low": [0.5, 1.5],
                "close": [1.2, 2.2],
                "adj_close": [1.1, 2.1],
                "volume": [100.0, 200.0],
            },
            index=index,
        )
    )


def test_get_prices_localizes_naive_index(monkeypatch):
    index = pd.date_range("2024-03-01", periods=2, freq="D")
    df = _single_level_df(index)
    monkeypatch.setattr(market.yf, "download", lambda *args, **kwargs: df.copy())

    result = market.MarketDataFetcher("AAPL").get_prices()

    assert result.index.tz is not None
    assert str(result.index.tz) == "UTC"
    assert result.index[0] == pd.Timestamp("2024-03-01 00:00:00+00:00", tz="UTC")


def test_get_prices_converts_existing_timezone(monkeypatch):
    index = pd.date_range("2024-04-01", periods=2, freq="D", tz="US/Eastern")
    df = _single_level_df(index)
    monkeypatch.setattr(market.yf, "download", lambda *args, **kwargs: df.copy())

    result = market.MarketDataFetcher("AAPL").get_prices()

    assert result.index.tz is not None
    assert str(result.index.tz) == "UTC"
    assert result.index[0] == pd.Timestamp("2024-04-01 04:00:00+00:00", tz="UTC")


def test_configure_yfinance_cache_respects_env(monkeypatch, tmp_path):
    original_dir = market._YF_CACHE_DIR
    custom_dir = tmp_path / "yf-cache"
    monkeypatch.setenv("HYPRL_YFINANCE_CACHE_DIR", str(custom_dir))
    calls: list[str] = []

    def _track_cache_location(path: str) -> None:
        calls.append(path)

    monkeypatch.setattr(market.yf, "set_tz_cache_location", _track_cache_location)

    resolved = market.configure_yfinance_cache_dir()

    assert resolved == custom_dir
    assert market._YF_CACHE_DIR == custom_dir
    assert custom_dir.exists()
    assert calls[-1] == str(custom_dir)

    market.configure_yfinance_cache_dir(str(original_dir))


def test_get_prices_uses_cache_when_fresh(monkeypatch, tmp_path):
    monkeypatch.setattr(market, "_CACHE_MAX_AGE", 86400)
    calls = {"count": 0}

    df = _single_level_df(pd.date_range("2024-05-01", periods=2, freq="h", tz="UTC"))

    def _mock_download(*args, **kwargs):
        calls["count"] += 1
        return df.copy()

    monkeypatch.setattr(market.yf, "download", _mock_download)
    fetcher = market.MarketDataFetcher("AAPL")
    fetcher.get_prices(interval="1h", period="5d")
    assert calls["count"] == 1
    calls["count"] = 0
    result = fetcher.get_prices(interval="1h", period="5d")
    assert calls["count"] == 0
    expected = df.rename(
        columns={
            "Open": "open",
            "High": "high",
            "Low": "low",
            "Close": "close",
            "Adj Close": "adj_close",
            "Volume": "volume",
        }
    )
    assert result.equals(expected)


def test_get_prices_falls_back_to_cache(monkeypatch, tmp_path):
    monkeypatch.setattr(market, "_CACHE_MAX_AGE", 86400)
    df = _single_level_df(pd.date_range("2024-06-01", periods=2, freq="h", tz="UTC"))

    def _mock_download_success(*args, **kwargs):
        return df.copy()

    fetcher = market.MarketDataFetcher("AAPL")
    monkeypatch.setattr(market.yf, "download", _mock_download_success)
    fetcher.get_prices(interval="1h", period="5d")

    def _mock_download_fail(*args, **kwargs):
        raise RuntimeError("network down")

    monkeypatch.setattr(market.yf, "download", _mock_download_fail)
    cached = fetcher.get_prices(interval="1h", period="5d")
    assert not cached.empty
