from __future__ import annotations

import json
import runpy
import sys
from pathlib import Path


def _run_cli(tmp_path: Path, drysim: str) -> dict:
    repo_root = Path(__file__).resolve().parents[1]
    script = repo_root / "scripts" / "run_supersearch.py"
    outdir = tmp_path / f"reports_{drysim}"
    cfg = tmp_path / "dummy.yaml"
    cfg.write_text("timeframe: '1h'\n", encoding="utf-8")

    argv = [
        "run_supersearch.py",
        "--config",
        str(cfg),
        "--tickers",
        "AAPL,MSFT,NVDA",
        "--timeframe",
        "1h",
        "--regimes",
        "on",
        "--constraints",
        "pf>=1.2,maxdd<=0.15,cvar95<=0.08,dsr>0,pboc<=0.10",
        "--out",
        str(outdir),
        "--drysim",
        drysim,
    ]
    sys.argv = argv
    runpy.run_path(str(script), run_name="__main__")
    data = json.loads((outdir / "gate_report.json").read_text(encoding="utf-8"))
    return data["cfg_001"]["gate"]


def test_gate_ok_transition(tmp_path: Path) -> None:
    gate = _run_cli(tmp_path, "ok")
    assert gate["all_ok"] is True
    assert all(item["status"] == "OK" for item in gate["by_metric"].values())


def test_gate_fail_transition(tmp_path: Path) -> None:
    gate = _run_cli(tmp_path, "fail")
    assert gate["all_ok"] is False
    assert any(item["status"] == "FAIL" for item in gate["by_metric"].values())
