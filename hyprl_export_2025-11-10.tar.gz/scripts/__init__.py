"""CLI utilities for HyprL."""
