#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List

from hyprl.risk.gates import check_constraints, parse_constraints

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="HyprL supersearch (gate-aware).")
    parser.add_argument("--config", required=True)
    parser.add_argument("--tickers", required=True, help="Comma-separated tickers.")
    parser.add_argument("--timeframe", default="1h")
    parser.add_argument("--regimes", choices=["on", "off"], default="off")
    parser.add_argument(
        "--constraints",
        default="maxdd<=0.15,cvar95<=0.08,dsr>0,pboc<=0.10",
        help='Comma list like "pf>=1.2,maxdd<=0.15,cvar95<=0.08,dsr>0,pboc<=0.10".',
    )
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--drysim", choices=["off", "ok", "fail"], default="off")
    return parser.parse_args()


def _row_from_result(config_id: str, metrics: Dict[str, Any], gate: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "config_id": config_id,
        "pf": metrics.get("pf"),
        "sharpe": metrics.get("sharpe"),
        "calmar": metrics.get("calmar"),
        "maxdd": metrics.get("maxdd"),
        "cvar95_m": metrics.get("cvar95_m"),
        "dsr": metrics.get("dsr"),
        "pboc": metrics.get("pboc"),
        "gate_all_ok": gate.get("all_ok"),
        "gate_by_metric": json.dumps(gate.get("by_metric", {}), ensure_ascii=False),
    }


def _save_leaderboard(outdir: Path, rows: List[Dict[str, Any]]) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    path = outdir / "leaderboard.csv"
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    headers = list(rows[0].keys())
    with path.open("w", encoding="utf-8") as handle:
        handle.write(",".join(headers) + "\n")
        for row in rows:
            handle.write(",".join("" if row[h] is None else str(row[h]) for h in headers) + "\n")


def _save_gate_report(outdir: Path, bundle: Dict[str, Any]) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "gate_report.json").write_text(json.dumps(bundle, ensure_ascii=False, indent=2), encoding="utf-8")


def _synthetic_metrics(mode: str) -> Dict[str, Any]:
    if mode == "ok":
        return {
            "pf": 1.25,
            "sharpe": 1.1,
            "calmar": 0.8,
            "maxdd": 0.12,
            "cvar95_m": 0.07,
            "dsr": 0.2,
            "pboc": 0.05,
        }
    if mode == "fail":
        return {
            "pf": 1.05,
            "sharpe": 0.3,
            "calmar": 0.3,
            "maxdd": 0.22,
            "cvar95_m": 0.10,
            "dsr": -0.1,
            "pboc": 0.30,
        }
    return {}


def _get_metrics_for_config(
    config_path: str,
    tickers: List[str],
    timeframe: str,
    regimes_on: bool,
) -> Dict[str, Any]:
    """
    TODO: replace with actual WFO evaluation + summarize_oos_metrics.
    """
    return {}


def main() -> None:
    args = parse_args()
    tickers = [t.strip() for t in args.tickers.split(",") if t.strip()]
    constraints = parse_constraints(args.constraints)
    outdir = args.out
    outdir.mkdir(parents=True, exist_ok=True)

    rows: List[Dict[str, Any]] = []
    gate_bundle: Dict[str, Any] = {}

    config_id = "cfg_001"
    metrics_oos = (
        _synthetic_metrics(args.drysim)
        if args.drysim != "off"
        else _get_metrics_for_config(args.config, tickers, args.timeframe, args.regimes == "on")
    )
    gate = check_constraints(metrics_oos, constraints)
    rows.append(_row_from_result(config_id, metrics_oos, gate))
    gate_bundle[config_id] = {"metrics_oos": metrics_oos, "gate": gate}

    _save_leaderboard(outdir, rows)
    _save_gate_report(outdir, gate_bundle)
    print(f"[INFO] Gate {config_id}: {gate}")
    print(f"[OK] Artefacts écrits dans {outdir}")


if __name__ == "__main__":
    main()
